#!/usr/bin/env python3
"""Contact sheet: python3 src/contact.py out.png cols img1 img2 ...  (labels from filenames)"""
import sys, os
from PIL import Image, ImageDraw, ImageFont
out, cols, files = sys.argv[1], int(sys.argv[2]), sys.argv[3:]
ims = [Image.open(f).convert('RGB') for f in files]
w, h = ims[0].size
sc = min(1.0, 360 / w)
tw, th = int(w * sc), int(h * sc)
rows = (len(ims) + cols - 1) // cols
pad, lab = 10, 26
sheet = Image.new('RGB', (cols * (tw + pad) + pad, rows * (th + pad + lab) + pad), (120, 124, 122))
d = ImageDraw.Draw(sheet)
try: font = ImageFont.truetype('/home/claude/films/assets/fonts/IBMPlexMono-500.ttf', 16)
except Exception: font = None
for i, (im, f) in enumerate(zip(ims, files)):
    r, c = divmod(i, cols)
    x, y = pad + c * (tw + pad), pad + r * (th + pad + lab)
    sheet.paste(im.resize((tw, th), Image.LANCZOS), (x, y + lab))
    d.text((x, y + 4), os.path.basename(f).rsplit('.', 1)[0].split('_')[-1] + 's', fill=(255, 255, 255), font=font)
sheet.save(out)
print(out, sheet.size)
