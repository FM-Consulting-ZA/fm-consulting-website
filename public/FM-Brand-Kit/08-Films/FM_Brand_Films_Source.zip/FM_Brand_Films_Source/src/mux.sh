#!/bin/bash
# mux.sh video.mp4 audio.wav out.mp4
# Static gain only (no compression): aim for -16 LUFS integrated but never above -1.5 dBTP,
# so the mix keeps the dynamics it was designed with. Then AAC 256 kb/s, 48 kHz.
set -e
V=$1; A=$2; O=$3
M=$(ffmpeg -hide_banner -nostats -i "$A" -af ebur128=peak=true -f null - 2>&1 | grep -A20 Summary)
I=$(echo "$M" | awk '/I:/{print $2; exit}')
TP=$(echo "$M" | awk '/Peak:/{print $2; exit}')
G=$(python3 -c "print(round(min(-16.0-($I), -1.5-($TP)), 2))")
ffmpeg -y -hide_banner -loglevel error -i "$V" -i "$A" -map 0:v -map 1:a -c:v copy \
  -af "volume=${G}dB,aresample=48000" -c:a aac -b:a 256k -ar 48000 -shortest -movflags +faststart "$O"
echo "muxed $O  (mix I=$I LUFS, TP=$TP dBTP, gain ${G} dB -> I≈$(python3 -c "print(round($I+$G,1))") LUFS)"
