#!/usr/bin/env python3
"""Animatic review: contact sheet every N seconds + motion-discontinuity report.
python3 src/review.py video.mp4 out_prefix [interval]"""
import sys, subprocess, numpy as np, json, os
from PIL import Image, ImageDraw, ImageFont
vid, pre = sys.argv[1], sys.argv[2]
iv = float(sys.argv[3]) if len(sys.argv) > 3 else 0.5
info = json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate,nb_frames','-of','json',vid]))['streams'][0]
w, h = info['width'], info['height']
fps = eval(info['r_frame_rate'])
raw = subprocess.check_output(['ffmpeg','-v','error','-i',vid,'-vf','scale=%d:%d'%(w//2,h//2),'-f','rawvideo','-pix_fmt','gray','-'])
fw, fh = w//2, h//2
fr = np.frombuffer(raw, np.uint8).reshape(-1, fh, fw).astype(np.float32)
n = len(fr)
d = np.abs(np.diff(fr, axis=0)).mean(axis=(1,2))
# spikes: diff much larger than neighbours
spikes = []
for i in range(1, len(d)-1):
    nb = max(d[i-1], d[i+1])
    if d[i] > 2.5 * nb + 0.4 and d[i] > 1.0: spikes.append((round((i+1)/fps,3), round(float(d[i]),2), round(float(nb),2)))
print('frames', n, 'dur', round(n/fps,2), 'fps', fps)
print('discontinuity spikes (t, diff, neighbour):', spikes[:30])
# stillness runs
still = d < 0.02
runs=[]; s=None
for i,v in enumerate(still):
    if v and s is None: s=i
    if not v and s is not None:
        if i-s >= fps*0.4: runs.append((round(s/fps,2), round(i/fps,2)))
        s=None
if s is not None: runs.append((round(s/fps,2), round(n/fps,2)))
print('still stretches >=0.4s:', runs)
# contact sheet
times = np.arange(0, n/fps, iv)
cols = 10
tw, th = 180, 320
rows = (len(times)+cols-1)//cols
sheet = Image.new('RGB', (cols*(tw+6)+6, rows*(th+26)+6), (110,114,112))
dr = ImageDraw.Draw(sheet)
font = ImageFont.truetype('/home/claude/films/assets/fonts/IBMPlexMono-500.ttf', 14)
full = subprocess.check_output(['ffmpeg','-v','error','-i',vid,'-vf','scale=%d:%d'%(tw,th),'-f','rawvideo','-pix_fmt','rgb24','-'])
fa = np.frombuffer(full, np.uint8).reshape(-1, th, tw, 3)
for k,t in enumerate(times):
    i = min(int(round(t*fps)), len(fa)-1)
    r,c = divmod(k, cols)
    x, y = 6+c*(tw+6), 6+r*(th+26)
    sheet.paste(Image.fromarray(fa[i]), (x, y+20))
    dr.text((x, y+2), f'{t:.1f}s', fill=(255,255,255), font=font)
sheet.save(pre+'_sheet.png')
# motion energy plot
import math
pw, ph = 1200, 200
plot = Image.new('RGB', (pw, ph+30), (250,250,248)); pd = ImageDraw.Draw(plot)
mx = max(d.max(), 1e-3)
for i,v in enumerate(d):
    x = int(i/len(d)*pw); y = int(ph - v/mx*ph)
    pd.line([(x,ph),(x,y)], fill=(40,44,42))
for s_ in range(int(n/fps)+1):
    x = int(s_*fps/len(d)*pw); pd.line([(x,ph),(x,ph+8)], fill=(200,0,0)); pd.text((x+2,ph+10), str(s_), fill=(0,0,0), font=font)
plot.save(pre+'_motion.png')
print('saved', pre+'_sheet.png', pre+'_motion.png')
