// FM Consulting — brand films. Shared constants and helpers.
// Everything here comes from the FM brand kit v1.0 (palette, fonts, logo files).
'use strict';
const fs = require('fs');
const path = require('path');
const { createCanvas, GlobalFonts, Path2D } = require('@napi-rs/canvas');

const ROOT = path.resolve(__dirname, '..');
const FONT_DIR = path.join(ROOT, 'assets/fonts');
const LOGO_DIR = path.join(ROOT, 'assets/logo');

// ---------------------------------------------------------------- palette (brand.py)
const C = {
  ink: '#0F1211', paper: '#F2F3F0', graphite: '#585E5B',
  silver: '#C6C9C4', mist: '#E4E6E1', white: '#FFFFFF',
};
const RGB = {
  ink: [15, 18, 17], paper: [242, 243, 240], graphite: [88, 94, 91],
  silver: [198, 201, 196], mist: [228, 230, 225], white: [255, 255, 255],
};

// ---------------------------------------------------------------- fonts (kit, OFL)
let fontsDone = false;
function registerFonts() {
  if (fontsDone) return;
  const reg = (f, alias) => GlobalFonts.registerFromPath(path.join(FONT_DIR, f), alias);
  reg('Archivo-Light.ttf', 'Archivo Light');
  reg('Archivo-Regular.ttf', 'Archivo Regular');
  reg('Archivo-Medium.ttf', 'Archivo Medium');
  reg('ArchivoExpanded-Regular.ttf', 'Archivo Expanded Regular');
  reg('ArchivoExpanded-Medium.ttf', 'Archivo Expanded Medium');
  reg('IBMPlexMono-400.ttf', 'Plex Mono');
  reg('IBMPlexMono-500.ttf', 'Plex Mono Medium');
  fontsDone = true;
}

// ---------------------------------------------------------------- genuine logo artwork
// The supplied SVGs are single outlined paths. We read the path data and the
// viewBox verbatim so geometry is never rebuilt by eye.
function loadLogo(name) {
  const s = fs.readFileSync(path.join(LOGO_DIR, name + '.svg'), 'utf8');
  const vb = s.match(/viewBox="([^"]+)"/)[1].split(/\s+/).map(Number);
  const d = s.match(/<path d="([^"]+)"/)[1];
  const fill = s.match(/fill="([^"]+)"/)[1];
  return { name, vb: { x: vb[0], y: vb[1], w: vb[2], h: vb[3] }, d, fill, path: new Path2D(d) };
}

// ---------------------------------------------------------------- maths
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a, b, t) => a + (b - a) * t;
const remap = (x, a, b, c = 0, d = 1) => lerp(c, d, clamp((x - a) / (b - a)));
const unlerp = (x, a, b) => clamp((x - a) / (b - a));
const smooth = t => { t = clamp(t); return t * t * (3 - 2 * t); };
const smoother = t => { t = clamp(t); return t * t * t * (t * (t * 6 - 15) + 10); };
const E = {
  inQuad: t => clamp(t) ** 2,
  outQuad: t => 1 - (1 - clamp(t)) ** 2,
  inCubic: t => clamp(t) ** 3,
  outCubic: t => 1 - (1 - clamp(t)) ** 3,
  inOutCubic: t => { t = clamp(t); return t < .5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2; },
  inQuint: t => clamp(t) ** 5,
  outQuint: t => 1 - (1 - clamp(t)) ** 5,
  inOutQuint: t => { t = clamp(t); return t < .5 ? 16 * t ** 5 : 1 - (-2 * t + 2) ** 5 / 2; },
  outExpo: t => { t = clamp(t); return t === 1 ? 1 : 1 - 2 ** (-10 * t); },
  inOutExpo: t => { t = clamp(t); if (t === 0 || t === 1) return t; return t < .5 ? 2 ** (20 * t - 10) / 2 : (2 - 2 ** (-20 * t + 10)) / 2; },
  inOutSine: t => -(Math.cos(Math.PI * clamp(t)) - 1) / 2,
};
const DEG = Math.PI / 180;

function mixRGB(a, b, t) {
  return [0, 1, 2].map(i => Math.round(lerp(a[i], b[i], t)));
}
const rgbStr = (c, a = 1) => a >= 1 ? `rgb(${c[0]},${c[1]},${c[2]})` : `rgba(${c[0]},${c[1]},${c[2]},${a})`;

// Text with manual tracking (letter-spacing in em), left/centre/right aligned.
function trackedText(ctx, str, x, y, sizePx, trackEm = 0, align = 'left') {
  const tr = trackEm * sizePx;
  const widths = [...str].map(ch => ctx.measureText(ch).width);
  const total = widths.reduce((a, b) => a + b, 0) + tr * (str.length - 1);
  let cx = align === 'left' ? x : align === 'center' ? x - total / 2 : x - total;
  const saved = ctx.textAlign; ctx.textAlign = 'left';
  [...str].forEach((ch, i) => { ctx.fillText(ch, cx, y); cx += widths[i] + tr; });
  ctx.textAlign = saved;
  return total;
}

// Deterministic PRNG
function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

module.exports = {
  C, RGB, registerFonts, loadLogo, clamp, lerp, remap, unlerp, smooth, smoother, E, DEG,
  mixRGB, rgbStr, trackedText, mulberry32, createCanvas, Path2D, ROOT,
};
