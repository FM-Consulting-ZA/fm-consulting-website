#!/usr/bin/env node
// Render driver: draws a film module frame by frame and pipes raw RGBA to FFmpeg.
// Temporal supersampling (motion blur) averages N sub-frames across a 180° shutter.
//
//   node src/render.js --film plumb --out out/plumb.mp4 [--w 1080 --h 1920 --fps 30 --sub 6]
//   node src/render.js --film plumb --stills 0,3.2,7.5 --outdir review/sf
'use strict';
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { createCanvas, registerFonts } = require('./common');

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => {
  if (a.startsWith('--')) acc.push([a.slice(2), arr[i + 1] && !arr[i + 1].startsWith('--') ? arr[i + 1] : true]);
  return acc;
}, []));

const FILM = require(`./${args.film}.js`);
const W = +(args.w || 1080), H = +(args.h || 1920), FPS = +(args.fps || 30);
const SUB = +(args.sub || 1), SHUTTER = +(args.shutter || 0.5);
const DW = 1080, DH = 1920; // design space
registerFonts();
const opts = { W: DW, H: DH, fps: FPS };
FILM.setup && FILM.setup(opts);

const canvas = createCanvas(W, H);
const ctx = canvas.getContext('2d');

function drawAt(t) {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 1;
  ctx.scale(W / DW, H / DH);
  FILM.draw(ctx, t, opts);
}

function frameRGBA(t) {
  const b = FILM.blurAt ? FILM.blurAt(t) : true;
  const n = SUB <= 1 ? 1 : (b === true ? SUB : b === false ? 1 : b);
  if (n <= 1) { drawAt(t); return Buffer.from(ctx.getImageData(0, 0, W, H).data.buffer); }
  const acc = new Uint32Array(W * H * 4);
  for (let k = 0; k < n; k++) {
    const tt = t + ((k + 0.5) / n - 0.5) * SHUTTER / FPS;
    drawAt(tt);
    const d = ctx.getImageData(0, 0, W, H).data;
    for (let i = 0; i < d.length; i++) acc[i] += d[i];
  }
  const out = Buffer.allocUnsafe(W * H * 4);
  const half = n >> 1;
  for (let i = 0; i < out.length; i++) out[i] = (acc[i] + half) / n | 0;
  return out;
}

async function renderVideo() {
  const t0 = +(args.from || 0), t1 = +(args.to || FILM.duration);
  const out = args.out;
  fs.mkdirSync(path.dirname(out), { recursive: true });
  const crf = args.crf || '14';
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error',
    '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', `${W}x${H}`, '-r', `${FPS}`, '-i', '-',
    '-vf', 'scale=out_color_matrix=bt709:out_range=tv,format=yuv420p',
    '-c:v', 'libx264', '-preset', args.preset || 'slow', '-crf', crf, '-tune', 'animation',
    '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-color_range', 'tv',
    '-movflags', '+faststart', out], { stdio: ['pipe', 'inherit', 'inherit'] });
  const nF = Math.round((t1 - t0) * FPS);
  const start = Date.now();
  for (let f = 0; f < nF; f++) {
    const t = t0 + f / FPS;
    const buf = frameRGBA(t);
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    if (f % 60 === 0) process.stderr.write(`  ${args.film} frame ${f}/${nF}  ${((Date.now() - start) / 1000).toFixed(0)}s\n`);
  }
  ff.stdin.end();
  await new Promise(r => ff.on('close', r));
  process.stderr.write(`done ${out} in ${((Date.now() - start) / 1000).toFixed(1)}s\n`);
}

function renderStills() {
  const dir = args.outdir || 'review';
  fs.mkdirSync(dir, { recursive: true });
  const times = String(args.stills).split(',').map(Number);
  for (const t of times) {
    const buf = frameRGBA(t);
    const c2 = createCanvas(W, H); const x2 = c2.getContext('2d');
    const id = x2.createImageData(W, H); id.data.set(buf); x2.putImageData(id, 0, 0);
    const f = path.join(dir, `${args.film}_${t.toFixed(2).padStart(5, '0')}.png`);
    fs.writeFileSync(f, c2.toBuffer('image/png'));
    console.log(f);
  }
}

function dumpEvents() {
  const ev = FILM.soundTrack ? FILM.soundTrack(FPS) : {};
  fs.writeFileSync(args.events, JSON.stringify(ev));
  console.log('events ->', args.events);
}

function renderCover() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.scale(W / DW, H / DH);
  FILM.drawCover(ctx, opts);
  fs.mkdirSync(path.dirname(args.cover), { recursive: true });
  fs.writeFileSync(args.cover, canvas.toBuffer('image/png'));
  console.log('cover ->', args.cover);
}

(async () => {
  if (args.cover) return renderCover();
  if (args.events) return dumpEvents();
  if (args.stills) return renderStills();
  await renderVideo();
})();
