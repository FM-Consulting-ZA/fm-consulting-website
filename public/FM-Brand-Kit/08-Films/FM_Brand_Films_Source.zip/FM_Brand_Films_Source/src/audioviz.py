#!/usr/bin/env python3
"""Spectrogram + short-term level plot with event markers. python3 src/audioviz.py a.wav events.json out.png"""
import sys, json, numpy as np
from scipy.io import wavfile
from scipy import signal
from PIL import Image, ImageDraw, ImageFont
wav, evf, out = sys.argv[1:4]
sr, x = wavfile.read(wav); x = x.astype(np.float32) / 32768; m = x.mean(axis=1)
ev = json.load(open(evf))['events']
f, t, S = signal.spectrogram(m, sr, nperseg=2048, noverlap=1536)
S = 10 * np.log10(S + 1e-12)
fmask = f <= 12000
S = S[fmask]; f = f[fmask]
# log-frequency rows
H, W = 360, 1400
rows = np.geomspace(30, 12000, H)
img = np.zeros((H, len(t)))
for i, fr in enumerate(rows):
    j = np.searchsorted(f, fr); j = min(j, len(f) - 1); img[H - 1 - i] = S[j]
img = np.clip((img + 110) / 80, 0, 1)
im = Image.fromarray((255 * (1 - img)).astype(np.uint8)).resize((W, H))
canvas = Image.new('RGB', (W, H + 190), (250, 250, 248)); canvas.paste(im.convert('RGB'), (0, 0))
d = ImageDraw.Draw(canvas)
font = ImageFont.truetype('/home/claude/films/assets/fonts/IBMPlexMono-400.ttf', 12)
dur = len(m) / sr
# short-term RMS (dBFS), 50 ms
win = int(0.05 * sr)
rms = np.sqrt(np.convolve(m ** 2, np.ones(win) / win, 'same'))
db = 20 * np.log10(rms + 1e-9)
for px in range(W):
    i = int(px / W * len(db)); v = np.clip((db[i] + 70) / 70, 0, 1)
    d.line([(px, H + 100), (px, H + 100 - int(v * 90))], fill=(40, 44, 42))
for k in range(0, 70, 10):
    y = H + 100 - int((70 - k) / 70 * 90); d.text((2, y - 6), f'-{k}', fill=(200, 0, 0), font=font)
for s in range(int(dur) + 1):
    x_ = int(s / dur * W); d.line([(x_, H + 100), (x_, H + 108)], fill=(0, 0, 0)); d.text((x_ + 2, H + 108), str(s), fill=(0, 0, 0), font=font)
seen = set(); row = 0
for e in ev:
    if e['type'] in ('meter', 'click', 'clack'): continue
    x_ = int(e['t'] / dur * W)
    d.line([(x_, 0), (x_, H)], fill=(220, 60, 60))
    d.text((x_ + 2, H + 125 + (row % 4) * 14), e['type'], fill=(160, 0, 0), font=font); row += 1
canvas.save(out)
print(out, 'peak dBFS', round(20*np.log10(np.abs(x).max()),1))
