#!/usr/bin/env python3
"""FM brand films — original synthesised sound design.

Every sound here is generated from maths (noise, filters, decaying modes), so
the soundtrack is wholly original: no samples, no libraries, no licences.
Event timings come from the animation code (render.js --events), so hits
land on the exact frame.

    python3 src/sound.py plumb    audio/plumb_events.json    audio/plumb.wav
    python3 src/sound.py shortcut audio/shortcut_events.json audio/shortcut.wav
"""
import sys, json
import numpy as np
from scipy import signal

SR = 48000
RNG = np.random.default_rng(20260926)


# ---------------------------------------------------------------- primitives
def secs(x): return int(round(x * SR))

def noise(n, seed=None):
    r = np.random.default_rng(seed) if seed is not None else RNG
    return r.standard_normal(n)

def brown(n, seed=None):
    w = noise(n, seed)
    b = np.cumsum(w)
    b = signal.sosfilt(signal.butter(1, 20, 'hp', fs=SR, output='sos'), b)
    return b / (np.abs(b).max() + 1e-9)

def filt(x, kind, f, order=2):
    return signal.sosfilt(signal.butter(order, f, kind, fs=SR, output='sos'), x)

def modal(freqs, decays, amps, dur=0.5, seed=None, jitter=0.0):
    t = np.arange(secs(dur)) / SR
    r = np.random.default_rng(seed)
    out = np.zeros_like(t)
    for f, d, a in zip(freqs, decays, amps):
        f2 = f * (1 + jitter * (r.random() - 0.5))
        out += a * np.sin(2 * np.pi * f2 * t + r.random() * 6.28) * np.exp(-t / d)
    # soft attack (1 ms) so nothing clicks digitally
    att = np.minimum(1, t / 0.001)
    return out * att

def transient(dur=0.004, hp=2000, seed=None):
    n = secs(dur)
    x = filt(noise(n, seed), 'hp', hp) * np.exp(-np.arange(n) / (n / 4))
    return x

def place(buf, x, t, gain=1.0, pan=0.0):
    """Add mono x into stereo buf at time t with constant-power pan (-1..1)."""
    i = secs(t)
    if i >= buf.shape[1] or i + len(x) <= 0: return
    j0 = max(0, -i); x = x[j0:]; i = max(i, 0)
    n = min(len(x), buf.shape[1] - i)
    a = (pan + 1) * np.pi / 4
    buf[0, i:i + n] += x[:n] * gain * np.cos(a)
    buf[1, i:i + n] += x[:n] * gain * np.sin(a)

def curve(values, fps, n):
    """Per-frame control curve -> per-sample, smoothed."""
    v = np.asarray(values, float)
    tt = np.arange(len(v)) / fps
    out = np.interp(np.arange(n) / SR, tt, v)
    return signal.sosfiltfilt(signal.butter(1, 18, 'lp', fs=SR, output='sos'), out)

def varlp(x, cutoff):
    """Time-varying one-pole low-pass in 128-sample blocks."""
    y = np.zeros_like(x); z = 0.0; B = 128
    for i in range(0, len(x), B):
        fc = float(np.clip(cutoff[min(i, len(cutoff) - 1)], 20, SR / 2.5))
        a = np.exp(-2 * np.pi * fc / SR)
        seg, zi = signal.lfilter([1 - a], [1, -a], x[i:i + B], zi=[z * a])
        y[i:i + B] = seg; z = seg[-1] if len(seg) else z
    return y

def reverb(x, secs_=0.9, wet=0.12, seed=3):
    """Small synthetic room: decorrelated exponential noise tails per channel."""
    n = secs(secs_)
    out = np.zeros((2, x.shape[1] + n))
    for ch in range(2):
        ir = noise(n, seed + ch) * np.exp(-np.arange(n) / (n / 5.5))
        ir = filt(ir, 'lp', 5200); ir = filt(ir, 'hp', 180)
        ir /= np.sqrt((ir ** 2).sum())
        y = signal.fftconvolve(x.mean(axis=0), ir); out[ch, :len(y)] = y[:out.shape[1]]
    return x + wet * out[:, :x.shape[1]]


# ---------------------------------------------------------------- signature
def fm_tock(seed=1):
    """The sign-off: a dry wooden tock with a warm low fifth underneath."""
    tock = modal([612, 1488, 2690, 4100], [0.085, 0.042, 0.022, 0.012], [1.0, 0.45, 0.22, 0.08], 0.5, seed)
    tr = transient(0.003, 2500, seed); tock[:len(tr)] += 0.35 * tr
    t = np.arange(secs(2.8)) / SR
    env = np.minimum(1, t / 0.035) * np.exp(-t / 1.05)
    bloom = (np.sin(2 * np.pi * 110 * t) * 0.55 + np.sin(2 * np.pi * 164.81 * t) * 0.32 +
             np.sin(2 * np.pi * 220 * t) * 0.16) * env
    out = np.zeros(len(t)); out[:len(tock)] += tock * 0.9; out += bloom * 0.28
    return out

def paper_crackle(dur, rate, seed, lo=1400, hi=9000):
    n = secs(dur)
    r = np.random.default_rng(seed)
    x = np.zeros(n)
    k = r.poisson(rate * dur)
    for p in r.integers(0, n, k):
        m = min(n - p, secs(0.006))
        x[p:p + m] += r.standard_normal(m) * np.exp(-np.arange(m) / (m / 5)) * r.uniform(0.2, 1)
    return filt(x, 'bp', [lo, hi])

def thump(freq=66, dur=0.35, seed=0):
    t = np.arange(secs(dur)) / SR
    body = np.sin(2 * np.pi * freq * t * (1 - 0.12 * t)) * np.exp(-t / 0.09)
    tr = filt(noise(len(t), seed), 'lp', 900) * np.exp(-t / 0.012)
    return body * 0.8 + tr * 0.35

def tick(seed=0, f=(2350, 5200), d=(0.010, 0.005), a=(1, 0.4)):
    x = modal(list(f), list(d), list(a), 0.05, seed)
    tr = transient(0.002, 3000, seed); x[:len(tr)] += 0.25 * tr
    return x


# ---------------------------------------------------------------- film 1
def plumb(data):
    dur = data['duration'] + 0.4
    n = secs(dur); buf = np.zeros((2, n)); fps = data['fps']
    ev = data['events']
    E = {e['type']: e['t'] for e in ev if e['type'] in ('reveal', 'stopdead', 'level', 'cut', 'lockup', 'fade', 'expand', 'drop')}
    edges = [e['t'] for e in ev if e['type'] == 'edge']

    # room air: the sound of the moving world (phase A it reads as the bar)
    creak = curve(data['creak'], fps, n)          # room angular speed, rad/s
    air = brown(n, 11)
    air_lo = varlp(air, 80 + 170 * creak) * (creak / 1.1) ** 1.3
    air_hi = filt(noise(n, 12), 'bp', [400, 1200]) * (creak / 1.1) ** 2 * 0.012
    buf += (air_lo * 0.55 + air_hi)[None, :] * 0.12

    # rolling: three balls, panned by position, rumble rises with speed
    rolls = np.asarray(data['roll'], float)
    for k in range(rolls.shape[1]):
        v = curve(rolls[:, k], fps, n)
        base = brown(n, 30 + k)
        r = varlp(base, 130 + 3.0 * v) * np.clip(v / 110, 0, 1.3) ** 1.1
        # the ledge rings faintly under the rolling
        ring = filt(noise(n, 60 + k), 'bp', [172, 186], 2) * 6 + filt(noise(n, 70 + k), 'bp', [414, 428], 2) * 3
        r += ring * np.clip(v / 120, 0, 1.2) ** 1.4 * 0.10
        r += filt(noise(n, 40 + k), 'bp', [700, 2200]) * np.clip(v / 140, 0, 1) ** 2 * 0.015
        pan = -0.25 + 0.25 * k
        place(buf, r * 0.13, 0, 1.0, pan)

    # collisions
    for e in ev:
        if e['type'] == 'clack':
            g = min(1.0, e['v'] / 90)
            x = modal([2150, 3950, 6150, 540, 1180], [0.045, 0.026, 0.014, 0.06, 0.035], [1, 0.5, 0.25, 0.5, 0.3], 0.3, int(e['t'] * 1000), 0.03)
            place(buf, x, e['t'], 0.35 * g, 0.35)
        elif e['type'] == 'click':
            g = min(1.0, e['v'] / 70)
            x = modal([2850, 5250, 7900], [0.03, 0.018, 0.01], [1, 0.45, 0.2], 0.2, int(e['t'] * 1000), 0.04)
            place(buf, x, e['t'], 0.22 * g, -0.1)
        elif e['type'] == 'edge':
            place(buf, tick(int(e['t'] * 100), (1800, 4300), (0.012, 0.006)), e['t'], 0.08, -0.45)

    # the swap: on the frame the bar arrives at vertical, the world's sound cuts out,
    # holds a breath of near-silence, then returns as the room is seen to be moving
    ts = np.ceil(E['stopdead'] * fps - 1e-6) / fps
    tt = np.arange(n) / SR
    gate = np.ones(n)
    d = tt - ts
    gate[(d >= 0) & (d < 0.025)] = 1 - 0.94 * (d[(d >= 0) & (d < 0.025)] / 0.025)
    gate[(d >= 0.025) & (d < 0.40)] = 0.06
    rec = (d >= 0.40) & (d < 1.40)
    gate[rec] = 0.06 + 0.94 * (0.5 - 0.5 * np.cos(np.pi * (d[rec] - 0.40)))
    buf *= gate[None, :]

    # the held breath: a thin high tone and a low one as the ball tips over (slow-motion)
    t0 = edges[-1] if edges else E['drop'] - 0.5
    t1 = ts
    t = np.arange(secs(t1 - t0 + 1.6)) / SR
    env = np.clip(t / (t1 - t0), 0, 1) ** 1.6 * np.exp(-np.clip(t - (t1 - t0), 0, None) / 0.045)
    breath = ((np.sin(2 * np.pi * 1318.5 * t) + np.sin(2 * np.pi * 1321.0 * t)) * 0.022 + np.sin(2 * np.pi * 55 * t) * 0.5) * env
    place(buf, breath, t0, 0.22)
    # duck everything else during the slow-motion
    spd = curve(data['speed'], fps, n)
    buf *= (0.35 + 0.65 * spd)[None, :]

    # the reveal: the bar stops dead, the world keeps going — sub swell as space opens
    t = np.arange(secs(2.6)) / SR
    swell = (np.sin(2 * np.pi * 43 * t) * 0.8 + filt(brown(len(t), 55), 'lp', 220) * 0.6) * \
            (np.minimum(1, t / 0.9) ** 2) * np.exp(-np.clip(t - 0.9, 0, None) / 0.7)
    place(buf, swell, ts + 0.05, 0.10)

    # level: the panel comes to rest
    place(buf, tick(9, (900, 2300), (0.02, 0.01), (1, 0.3)), E['level'], 0.10)
    # expand: the room opens to become the page
    t = np.arange(secs(1.0)) / SR
    place(buf, filt(noise(len(t), 77), 'bp', [300, 3000]) * np.sin(np.pi * t / 1.0) ** 2, E['expand'], 0.035)

    # sign-off
    place(buf, fm_tock(1), np.ceil(E['cut'] * fps - 1e-6) / fps, 0.45)   # on the first frame of the mark
    t = np.arange(secs(2.4)) / SR
    bloom2 = np.sin(2 * np.pi * 82.41 * t) * np.minimum(1, t / 0.4) * np.exp(-t / 1.1)
    place(buf, bloom2, E['lockup'], 0.06)

    buf = reverb(buf, 1.1, 0.10)
    return buf


# ---------------------------------------------------------------- film 2
def shortcut(data):
    dur = data['duration'] + 0.4
    n = secs(dur); buf = np.zeros((2, n)); fps = data['fps']
    ev = data['events']
    E = {}
    for e in ev: E.setdefault(e['type'], e['t'])

    # the traveller: a tiny clockwork tick train, rate follows speed
    sp = np.asarray(data['speed'], float)
    phase = 0.0; ticks = []
    for f in range(len(sp)):
        inc = sp[f] / fps / 34.0               # one tick every 34 px travelled
        p0 = phase; phase += inc
        while phase >= 1:
            frac = (1 - p0) / inc if inc > 0 else 0
            ticks.append((f + frac) / fps); phase -= 1; p0 -= 1
    for i, tt in enumerate(ticks):
        x = modal([1650, 3900], [0.006, 0.003], [1, 0.35], 0.03, 100 + i, 0.08)
        place(buf, x, tt, 0.035, -0.15)
    # the creep forward and back: two ticks each way
    for j, dt_ in enumerate([0.0, 0.09]):
        place(buf, modal([1650, 3900], [0.006, 0.003], [1, 0.35], 0.03, 900 + j, 0.08), E['creep'] + 0.03 + dt_, 0.07, -0.15)
    for j, dt_ in enumerate([0.0, 0.13]):
        place(buf, modal([1580, 3700], [0.006, 0.003], [1, 0.35], 0.03, 910 + j, 0.08), E['creepback'] + 0.04 + dt_, 0.055, -0.15)
    # tyre hiss, whisper-level
    v = curve(sp, fps, n)
    hiss = filt(noise(n, 5), 'bp', [2200, 7000]) * np.clip(v / 800, 0, 1) ** 1.5
    buf += hiss[None, :] * 0.006

    # the meter: a crisp two-part tick every 0.1 km
    for i, e in enumerate([e for e in ev if e['type'] == 'meter']):
        place(buf, tick(200 + i, (2400, 5100), (0.012, 0.006)), e['t'], 0.075, 0.3)
        place(buf, tick(300 + i, (3100, 6400), (0.006, 0.003)), e['t'] + 0.018, 0.028, 0.3)

    # measure: a tape measure paying out
    t0 = E['measure']; L = 0.36
    k = 0; tt = 0.0
    while tt < L:
        rate = 55 + 90 * (tt / L)
        place(buf, modal([2600, 5200], [0.004, 0.002], [1, .4], 0.02, 500 + k, 0.2), t0 + tt, 0.05 * (1 - 0.3 * tt / L), 0.05)
        tt += 1 / rate; k += 1
    place(buf, tick(610, (1900, 4200), (0.015, 0.008)), t0 + L, 0.12, 0.05)
    place(buf, tick(611, (2600, 5600), (0.008, 0.004)), E['label'] + 0.05, 0.06, 0.2)

    # guide: a pen ruling a line
    t = np.arange(secs(0.46)) / SR
    scratch = filt(noise(len(t), 612), 'bp', [2500, 7500]) * (0.6 + 0.4 * np.abs(np.sin(2 * np.pi * 23 * t)))
    scratch *= np.minimum(1, t / 0.03) * np.minimum(1, (0.46 - t) / 0.08)
    place(buf, scratch, E['guide'], 0.028, 0.0)

    # lift: the sheet flexes
    place(buf, paper_crackle(0.34, 45, 613) * np.hanning(secs(0.34)), E['lift'], 0.06, 0.1)

    # fold and unfold: air moved by the flap, crackle at the hinge, a soft landing
    fl = curve(data['flap'], fps, n)
    whoosh = filt(noise(n, 614), 'bp', [250, 2400]) * np.clip(fl / 6.0, 0, 1) ** 1.4
    whoosh += filt(brown(n, 615), 'lp', 300) * np.clip(fl / 6.0, 0, 1) ** 1.2 * 0.6
    buf += whoosh[None, :] * 0.10
    place(buf, paper_crackle(0.5, 70, 616, 1200, 9000) * np.hanning(secs(0.5)), E['fold'] + 0.05, 0.05, 0.1)
    place(buf, thump(64, 0.4, 617), E['land'], 0.22, -0.05)
    place(buf, paper_crackle(0.08, 120, 618, 900, 6000), E['land'], 0.05)
    # the meter drops to zero: a double tick
    place(buf, tick(619, (2400, 5100), (0.012, 0.006)), E['zero'] + 0.14, 0.17, 0.3)
    place(buf, tick(620, (2400, 5100), (0.012, 0.006)), E['zero'] + 0.23, 0.13, 0.3)
    place(buf, paper_crackle(0.45, 60, 621, 1200, 9000) * np.hanning(secs(0.45)), E['unfold'] + 0.05, 0.045, -0.1)
    place(buf, thump(90, 0.2, 622), E['unfolded'] - 0.02, 0.10)

    # zoom: a breath of space
    z = curve(data['zoom'], fps, n)
    buf += (filt(brown(n, 623), 'lp', 400) * np.clip(z / 1.2, 0, 1) ** 1.5)[None, :] * 0.05

    # sign-off
    place(buf, fm_tock(1), E['lockup'], 0.45)

    buf = reverb(buf, 0.9, 0.12)
    return buf


def limit(buf, thr=0.5, look=0.0015, rel=0.09):
    from scipy.ndimage import maximum_filter1d, minimum_filter1d
    pk = np.abs(buf).max(axis=0)
    pk = maximum_filter1d(pk, secs(look) * 2 + 1)
    g = np.minimum(1.0, thr / (pk + 1e-9))
    g = minimum_filter1d(g, secs(look) * 2 + 1)
    # release: one-pole rising back to 1
    a = np.exp(-1 / (rel * SR)); out = np.empty_like(g); z = 1.0
    for i in range(0, len(g), 64):
        blk = g[i:i + 64]
        for j in range(len(blk)):
            z = min(blk[j], 1 - (1 - z) * a)     # instant attack, exponential release toward unity
            out[i + j] = z
    return buf * out[None, :]

def finish(buf):
    # gentle high-pass for mud, peak control, soft clip safety, 0.25 s tail fade
    buf = np.stack([filt(ch, 'hp', 28) for ch in buf])
    buf = buf / (np.abs(buf).max() + 1e-9)
    buf = limit(buf, 0.30)
    buf = buf / (np.abs(buf).max() + 1e-9) * 0.8
    buf = np.tanh(buf * 1.05) / np.tanh(1.05)
    fade = secs(0.25)
    buf[:, -fade:] *= np.linspace(1, 0, fade)[None, :]
    return buf


if __name__ == '__main__':
    film, evf, out = sys.argv[1:4]
    data = json.load(open(evf))
    buf = plumb(data) if film == 'plumb' else shortcut(data)
    buf = finish(buf)[:, :secs(data['duration'])]
    from scipy.io import wavfile
    wavfile.write(out, SR, (buf.T * 32767).astype(np.int16))
    print('wrote', out, buf.shape, 'peak', float(np.abs(buf).max()))
