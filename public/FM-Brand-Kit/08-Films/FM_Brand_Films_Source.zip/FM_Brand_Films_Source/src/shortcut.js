// FILM 2 — SHORTCUT
// A small ink disc drives a mountain road, hairpin after hairpin. It stops,
// measures, and folds the map so the summit lands on it.
//
// Units are design pixels (1080 × 1920). The sheet is a plane in 3D; the flap
// rotates about the perpendicular bisector of traveller→summit, and every
// point on it is projected with a real perspective camera.
'use strict';
const { C, RGB, loadLogo, clamp, lerp, remap, unlerp, smooth, smoother, E, DEG,
  mixRGB, rgbStr, trackedText, mulberry32 } = require('./common');

const W = 1080, H = 1920;
const T = {
  drive0: 0.0,           // traveller already moving at frame 1, first hairpin in under half a second
  stop: 3.95,            // comes to rest after three hairpins, creeps, thinks better of it
  measure0: 4.88, measure1: 5.22,
  guide0: 5.40, guide1: 5.80,
  measureOut0: 5.60, measureOut1: 5.95,
  lift0: 5.95, lift1: 6.28,     // anticipation: the sheet breathes
  fold0: 6.36, fold1: 7.46,     // the fold
  hold1: 8.30,
  unfold0: 8.30, unfold1: 9.30,
  settle1: 9.75,
  line0: 9.55, line1: 9.90,     // "The road was a suggestion."
  hud0: 11.25, hud1: 11.65,     // meter and line step back (beat extended 0.8 s so the line can be read)
  zoom0: 11.35, zoom1: 12.85,   // the map, seen whole
  lock0: 12.85, lock1: 13.45,
  end: 15.80,
};
const duration = T.end;

// ---------------------------------------------------------------- road
const ROWS = 9, Y0 = 1420, DY = 112.5;
function buildRoad() {
  const rnd = mulberry32(11);
  const turns = [];
  for (let k = 0; k < ROWS - 1; k++) turns.push(k % 2 === 0 ? 872 + Math.round((rnd() - 0.5) * 60) : 208 + Math.round((rnd() - 0.5) * 60));
  const pts = [];
  const push = (x, y) => pts.push([x, y]);
  // entry: rises from the bottom edge into the first row
  const xs0 = 208;
  for (let k = 0; k <= 30; k++) { const u = k / 30; push(xs0 - 26 * (1 - E.outCubic(u)), lerp(1990, Y0 + 60, u)); }
  for (let k = 1; k <= 24; k++) { const th = k / 24 * Math.PI / 2; push(xs0 + (1 - Math.cos(th)) * 60, Y0 + 60 - Math.sin(th) * 60); }
  let xStart = xs0 + 60;
  for (let i = 0; i < ROWS; i++) {
    const y = Y0 - i * DY, right = i % 2 === 0;
    const last = i === ROWS - 1;
    const xEnd = last ? 612 : turns[i];
    const n = 70;
    for (let k = 1; k <= n; k++) {
      const u = k / n;
      push(lerp(xStart, xEnd, u), y - 8 * u + Math.sin(u * Math.PI) * (right ? 6 : -5));
    }
    if (!last) {
      const r = (DY - 8) / 2, dir = right ? 1 : -1;
      for (let k = 1; k <= 44; k++) {
        const th = (k / 44) * Math.PI;
        push(xEnd + dir * Math.sin(th) * r * 0.95, (y - 8) - (1 - Math.cos(th)) * r);
      }
      xStart = xEnd;
    }
  }
  // summit spur
  const L = pts[pts.length - 1];
  const target = [SUMMIT.x, SUMMIT.y + RING.r + 4];
  for (let k = 1; k <= 40; k++) {
    const u = k / 40;
    // quadratic curve up to the ring
    const cx = target[0] + 10, cy = L[1];
    push((1 - u) ** 2 * L[0] + 2 * (1 - u) * u * cx + u * u * target[0], (1 - u) ** 2 * L[1] + 2 * (1 - u) * u * cy + u * u * target[1]);
  }
  return resample(pts, 3);
}
function resample(pts, step) {
  const out = [pts[0]]; let acc = 0;
  for (let i = 1; i < pts.length; i++) {
    let [x0, y0] = out[out.length - 1];
    const [x1, y1] = pts[i];
    let d = Math.hypot(x1 - pts[i - 1][0], y1 - pts[i - 1][1]);
    let px = pts[i - 1][0], py = pts[i - 1][1];
    while (acc + d >= step) {
      const u = (step - acc) / d;
      px = px + (x1 - px) * u; py = py + (y1 - py) * u;
      out.push([px, py]); d = Math.hypot(x1 - px, y1 - py); acc = 0;
    }
    acc += d;
  }
  return out;
}

const SUMMIT = { x: 712, y: 392 };
const RING = { r: 26, t: 5 };
const TRAV_R = 15;
const ROAD_W = 5;

// ---------------------------------------------------------------- contours
function buildContours() {
  const h = (x, y) => {
    const a = Math.exp(-(((x - 712) / 420) ** 2 + ((y - 392) / 700) ** 2));
    const b = 0.55 * Math.exp(-(((x - 260) / 300) ** 2 + ((y - 650) / 420) ** 2));
    const c = 0.35 * Math.exp(-(((x - 980) / 260) ** 2 + ((y - 1250) / 380) ** 2));
    return a + b + c;
  };
  const step = 10, nx = Math.ceil(1400 / step), ny = Math.ceil(2400 / step);
  const ox = -160, oy = -240;
  const grid = [];
  for (let j = 0; j <= ny; j++) { const row = []; for (let i = 0; i <= nx; i++) row.push(h(ox + i * step, oy + j * step)); grid.push(row); }
  const levels = [0.22, 0.34, 0.46, 0.58, 0.70, 0.82, 0.92];
  const lines = [];
  for (const L of levels) {
    const segs = [];
    for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
      const v = [grid[j][i], grid[j][i + 1], grid[j + 1][i + 1], grid[j + 1][i]];
      const P = [[ox + i * step, oy + j * step], [ox + (i + 1) * step, oy + j * step], [ox + (i + 1) * step, oy + (j + 1) * step], [ox + i * step, oy + (j + 1) * step]];
      const e = [];
      for (let k = 0; k < 4; k++) {
        const a = v[k], b = v[(k + 1) % 4];
        if ((a < L) !== (b < L)) { const u = (L - a) / (b - a); e.push([lerp(P[k][0], P[(k + 1) % 4][0], u), lerp(P[k][1], P[(k + 1) % 4][1], u)]); }
      }
      if (e.length === 2) segs.push(e); else if (e.length === 4) { segs.push([e[0], e[1]]); segs.push([e[2], e[3]]); }
    }
    lines.push(chain(segs));
  }
  return lines.flat().filter(l => l.length > 12);
}
function chain(segs) {
  const key = p => `${p[0].toFixed(2)},${p[1].toFixed(2)}`;
  const map = new Map();
  segs.forEach((s, i) => { for (const p of s) { const k = key(p); if (!map.has(k)) map.set(k, []); map.get(k).push(i); } });
  const used = new Array(segs.length).fill(false), out = [];
  for (let i = 0; i < segs.length; i++) {
    if (used[i]) continue;
    used[i] = true; let line = [segs[i][0], segs[i][1]];
    for (const end of [1, 0]) {
      let grow = true;
      while (grow) {
        grow = false;
        const tip = end ? line[line.length - 1] : line[0];
        for (const j of map.get(key(tip)) || []) {
          if (used[j]) continue;
          used[j] = true;
          const nxt = key(segs[j][0]) === key(tip) ? segs[j][1] : segs[j][0];
          if (end) line.push(nxt); else line.unshift(nxt);
          grow = true; break;
        }
      }
    }
    out.push(line);
  }
  return out;
}

// ---------------------------------------------------------------- drive
let ROAD, CUM, CONTOURS, DRIVE, S_STOP, TRAV_STOP, FOLD, LOCKUP;
function cumulative(pts) { const c = [0]; for (let i = 1; i < pts.length; i++) c.push(c[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])); return c; }
function pointAt(s) {
  s = clamp(s, 0, CUM[CUM.length - 1]);
  let lo = 0, hi = CUM.length - 1;
  while (hi - lo > 1) { const m = (lo + hi) >> 1; if (CUM[m] <= s) lo = m; else hi = m; }
  const u = (s - CUM[lo]) / (CUM[hi] - CUM[lo] || 1);
  return [lerp(ROAD[lo][0], ROAD[hi][0], u), lerp(ROAD[lo][1], ROAD[hi][1], u), lo];
}
function curvatureAt(i) {
  const a = ROAD[Math.max(0, i - 4)], b = ROAD[i], c = ROAD[Math.min(ROAD.length - 1, i + 4)];
  const ab = Math.hypot(b[0] - a[0], b[1] - a[1]), bc = Math.hypot(c[0] - b[0], c[1] - b[1]), ca = Math.hypot(a[0] - c[0], a[1] - c[1]);
  const cross = Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]));
  return ab * bc * ca > 0 ? 2 * cross / (ab * bc * ca) : 0;
}
// speed profile along the road: fast on straights, braking into hairpins
function planDrive(s0, s1, tStart, tTarget) {
  const n = 1200, ds = (s1 - s0) / n;
  const run = (vmax, alat, acc, dec) => {
    const v = new Float64Array(n + 1);
    for (let k = 0; k <= n; k++) {
      const i = pointAt(s0 + k * ds)[2];
      const kap = Math.max(1e-6, curvatureAt(i));
      v[k] = Math.min(vmax, Math.sqrt(alat / kap));
    }
    v[0] = Math.min(v[0], vmax * 0.92);
    v[n] = 0;
    for (let k = 1; k <= n; k++) v[k] = Math.min(v[k], Math.sqrt(v[k - 1] ** 2 + 2 * acc * ds));
    for (let k = n - 1; k >= 0; k--) v[k] = Math.min(v[k], Math.sqrt(v[k + 1] ** 2 + 2 * dec * ds));
    const tt = [0];
    for (let k = 1; k <= n; k++) tt.push(tt[k - 1] + ds / Math.max(1, (v[k] + v[k - 1]) / 2));
    return { v, tt };
  };
  let lo = 200, hi = 2000, best;
  for (let it = 0; it < 30; it++) {
    const m = (lo + hi) / 2; const r = run(m, m * m * 0.0032, m * 1.7, m * 1.35);
    best = r;
    if (r.tt[n] > tTarget - tStart) lo = m; else hi = m;
  }
  return { s0, s1, ds, tStart, ...best, n };
}
function driveS(t) {
  const D = DRIVE;
  if (t <= D.tStart) return D.s0 + D.v[0] * (t - D.tStart);
  const tr = t - D.tStart;
  if (tr >= D.tt[D.n]) return D.s1;
  let lo = 0, hi = D.n;
  while (hi - lo > 1) { const m = (lo + hi) >> 1; if (D.tt[m] <= tr) lo = m; else hi = m; }
  const u = (tr - D.tt[lo]) / (D.tt[hi] - D.tt[lo]);
  return D.s0 + (lo + u) * D.ds;
}
// after stopping: the smallest overshoot, then a creep toward the next bend… and it thinks better of it
function hesitate(t) {
  let o = 0;
  if (t > T.stop) o += 4 * Math.sin(unlerp(t, T.stop, T.stop + 0.28) * Math.PI) * (1 - unlerp(t, T.stop, T.stop + 0.28));
  const c0 = T.stop + 0.30, c1 = c0 + 0.20, c2 = c1 + 0.10, c3 = c2 + 0.26;
  if (t > c0 && t < c1) o += 9 * E.inOutCubic(unlerp(t, c0, c1));
  else if (t >= c1 && t < c2) o += 9;
  else if (t >= c2 && t < c3) o += 9 * (1 - E.inOutCubic(unlerp(t, c2, c3)));
  return o;
}
function speedAt(t) { const dt = 1 / 240; return Math.abs(driveS(t + dt) - driveS(t - dt)) / (2 * dt); }

// ---------------------------------------------------------------- fold geometry
function setupFold(P, Q) {
  const M = [(P[0] + Q[0]) / 2, (P[1] + Q[1]) / 2];
  const d = [Q[0] - P[0], Q[1] - P[1]], L = Math.hypot(d[0], d[1]);
  const n = [d[0] / L, d[1] / L];          // in-plane normal, toward the summit side
  const a = [-n[1], n[0]];                   // fold axis direction
  return { M, n, a, L };
}
const CAM = { cx: 540, cy: 960, D: 11000 };
function side(p) { return (p[0] - FOLD.M[0]) * FOLD.n[0] + (p[1] - FOLD.M[1]) * FOLD.n[1]; }
function proj3(p, phi) {
  const dx = p[0] - FOLD.M[0], dy = p[1] - FOLD.M[1];
  const u = dx * FOLD.a[0] + dy * FOLD.a[1];
  const v = dx * FOLD.n[0] + dy * FOLD.n[1];
  if (v <= 0) return [p[0], p[1], 0];
  const X = FOLD.M[0] + u * FOLD.a[0] + v * Math.cos(phi) * FOLD.n[0];
  const Y = FOLD.M[1] + u * FOLD.a[1] + v * Math.cos(phi) * FOLD.n[1];
  const Z = v * Math.sin(phi) + 0.2 * Math.sin(phi / 2);   // lifts toward camera
  return [X, Y, Z];
}
function project(p3) {
  const k = CAM.D / (CAM.D - p3[2]);
  return [CAM.cx + (p3[0] - CAM.cx) * k, CAM.cy + (p3[1] - CAM.cy) * k, k];
}
const P = (p, phi) => project(proj3(p, phi));

// clip a polygon to the half-plane side(p) >= 0 (flap) or <= 0 (base)
function clipPoly(poly, flap) {
  const out = [];
  const inside = p => flap ? side(p) >= 0 : side(p) <= 0;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    const ia = inside(a), ib = inside(b);
    if (ia) out.push(a);
    if (ia !== ib) { const sa = side(a), sb = side(b), u = sa / (sa - sb); out.push([lerp(a[0], b[0], u), lerp(a[1], b[1], u)]); }
  }
  return out;
}
// split an open polyline by the fold line
function splitLine(pts, flap) {
  const res = []; let cur = [];
  const inside = p => flap ? side(p) >= 0 : side(p) <= 0;
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i];
    if (inside(p)) {
      if (!cur.length && i > 0) { const q = pts[i - 1], sa = side(q), sb = side(p), u = sa / (sa - sb); cur.push([lerp(q[0], p[0], u), lerp(q[1], p[1], u)]); }
      cur.push(p);
    } else if (cur.length) {
      const q = pts[i - 1], sa = side(q), sb = side(p), u = sa / (sa - sb); cur.push([lerp(q[0], p[0], u), lerp(q[1], p[1], u)]);
      res.push(cur); cur = [];
    }
  }
  if (cur.length) res.push(cur);
  return res;
}

// ---------------------------------------------------------------- setup
function setup() {
  ROAD = buildRoad(); CUM = cumulative(ROAD);
  CONTOURS = buildContours().map(l => resample(l, 6));
  LOCKUP = loadLogo('fm-lockup-stacked-descriptor-reverse');
  // traveller: frame 1 already rolling on row 1; stops on row 4 after three hairpins
  const sStart = findS(p => p[1] < Y0 + 2 && p[0] > 600);
  const sHair = []; // not needed; stop point chosen on row 4
  const row4y = Y0 - 3 * DY;
  S_STOP = findS(p => Math.abs(p[1] - (row4y - 10)) < 14 && p[0] < 425 && p[0] > 395, sStart + 1000);
  DRIVE = planDrive(sStart, S_STOP, 0, T.stop);
  TRAV_STOP = pointAt(S_STOP);
  FOLD = setupFold([TRAV_STOP[0], TRAV_STOP[1]], [SUMMIT.x, SUMMIT.y]);
}
function findS(pred, from = 0) {
  for (let i = 0; i < ROAD.length; i++) if (CUM[i] >= from && pred(ROAD[i])) return CUM[i];
  throw new Error('findS failed');
}

// ---------------------------------------------------------------- fold angle
function foldPhi(t) {
  if (t < T.lift0) return 0;
  if (t < T.fold0) {
    // the corner breathes: lifts 7°, settles to 4°
    const u = unlerp(t, T.lift0, T.lift1);
    return (E.outCubic(u) * 2.6 - smooth(unlerp(t, T.lift1, T.fold0)) * 1.2) * DEG;
  }
  if (t < T.fold1) {
    const u = unlerp(t, T.fold0, T.fold1);
    // slow start, committed swing, a soft landing with the smallest rebound
    // gravity takes it: slow to leave the table, readable in the air, a soft landing
    const e = u < 0.88 ? (0.55 * smooth(u / 0.88) + 0.45 * E.inCubic(u / 0.88)) * 1.01 : 1.01 - 0.01 * smooth((u - 0.88) / 0.12);
    return lerp(1.4 * DEG, Math.PI, e);
  }
  if (t < T.unfold0) return Math.PI;
  if (t < T.unfold1) {
    const u = unlerp(t, T.unfold0, T.unfold1);
    return lerp(Math.PI, 0, smoother(u));
  }
  // paper memory: the flap relaxes a hair and settles
  const u = unlerp(t, T.unfold1, T.settle1);
  return Math.sin(u * Math.PI) * 1.6 * DEG * (1 - u);
}

// ---------------------------------------------------------------- drawing helpers
function polyPath(ctx, pts) { ctx.beginPath(); pts.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.closePath(); }
function linePath(ctx, pts) { ctx.beginPath(); pts.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); }
function circlePts(cx, cy, r, n = 72) { const o = []; for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; o.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); } return o; }
function signedArea(pts) { let s = 0; for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length]; s += a[0] * b[1] - b[0] * a[1]; } return s / 2; }

const SHEET = [[-260, -420], [1340, -420], [1340, 2340], [-260, 2340]];
const ZOOM = { k: 0.33, cx: 540, cy: 620 };

// draw the sheet's printed content through a mapping fn (identity for base)
function drawPrint(ctx, map, which, opts) {
  const { roadA, contourA, ghost } = opts;
  const scaleAt = p => (map(p)[2] || 1);
  // contours
  if (contourA > 0) {
    ctx.strokeStyle = ghost ? rgbStr(RGB.ink, 0.05 * contourA) : rgbStr(RGB.silver, contourA);
    ctx.lineWidth = 2; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    for (const l of CONTOURS) for (const seg of (which === 'all' ? [l] : splitLine(l, which === 'flap'))) {
      if (seg.length < 2) continue; linePath(ctx, seg.map(p => map(p))); ctx.stroke();
    }
  }
  // road
  if (roadA > 0) {
    ctx.strokeStyle = ghost ? rgbStr(RGB.ink, 0.13 * roadA) : rgbStr(RGB.ink, roadA);
    ctx.lineWidth = ROAD_W; ctx.lineJoin = 'round'; ctx.lineCap = 'butt';
    for (const seg of (which === 'all' ? [ROAD] : splitLine(ROAD, which === 'flap'))) {
      if (seg.length < 2) continue;
      const m = seg.map(p => map(p));
      ctx.lineWidth = ROAD_W * (m[0][2] || 1) / Math.sqrt(CAMK);
      linePath(ctx, m); ctx.stroke();
    }
  }
}
function drawRing(ctx, map, alpha, ghost) {
  const o = circlePts(SUMMIT.x, SUMMIT.y, RING.r).map(map), i = circlePts(SUMMIT.x, SUMMIT.y, RING.r - RING.t).map(map).reverse();
  ctx.fillStyle = ghost ? rgbStr(RGB.ink, 0.30 * alpha) : rgbStr(RGB.ink, alpha);
  ctx.beginPath(); o.forEach((p, k) => k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.closePath();
  i.forEach((p, k) => k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.closePath();
  ctx.fill('evenodd');
}
function drawDisc(ctx, map, cx, cy, r, fill) {
  const pts = circlePts(cx, cy, r, 48).map(map);
  ctx.fillStyle = fill; polyPath(ctx, pts); ctx.fill();
}
const ID = p => [p[0], p[1], 1];

// ---------------------------------------------------------------- HUD
function drawHUD(ctx, t) {
  const total = CUM[CUM.length - 1];
  const kmPerPx = 3.2 / (total - DRIVE.s0 + 40);
  let s = t < T.fold1 - 0.12 ? driveS(t) : null;
  let km = s === null ? 0 : Math.max(0, (total - s) * kmPerPx);
  let str = km.toFixed(1);
  const a = 1 - smooth(unlerp(t, T.clear0, T.clear1)) * 0.0;
  ctx.save();
  ctx.fillStyle = C.ink;
  ctx.font = '500 58px "Plex Mono Medium"';
  ctx.textBaseline = 'alphabetic';
  const x = 96, y = 1660;
  ctx.fillText(str, x, y);
  const w = ctx.measureText(str).width;
  ctx.font = '30px "Plex Mono"'; ctx.fillStyle = C.graphite;
  ctx.fillText('KM', x + w + 14, y);
  ctx.restore();
}
function hudKm(t) {
  const total = CUM[CUM.length - 1];
  const kmPerPx = 3.2 / (total - DRIVE.s0 + 40);
  if (t >= T.fold1 - 0.12) return 0;
  return Math.max(0, (total - driveS(t)) * kmPerPx);
}

// measurement line and fold guide
function drawMeasure(ctx, t) {
  const a1 = smooth(unlerp(t, T.measure0, T.measure1)) * (1 - smooth(unlerp(t, T.measureOut0, T.measureOut1)));
  const P0 = [TRAV_STOP[0], TRAV_STOP[1]], Q = [SUMMIT.x, SUMMIT.y];
  const dir = [Q[0] - P0[0], Q[1] - P0[1]], L = Math.hypot(...dir);
  const ux = dir[0] / L, uy = dir[1] / L;
  if (a1 > 0) {
    const grow = E.outCubic(unlerp(t, T.measure0, T.measure1));
    const s0 = TRAV_R + 8, s1 = s0 + (L - RING.r - 8 - s0) * grow;
    ctx.save(); ctx.globalAlpha = a1;
    ctx.strokeStyle = C.graphite; ctx.lineWidth = 2; ctx.setLineDash([10, 9]);
    ctx.beginPath(); ctx.moveTo(P0[0] + ux * s0, P0[1] + uy * s0); ctx.lineTo(P0[0] + ux * s1, P0[1] + uy * s1); ctx.stroke();
    ctx.setLineDash([]);
    // label: straight-line distance
    const km = (L * 3.2 / (CUM[CUM.length - 1] - DRIVE.s0 + 40));
    const lx = P0[0] + ux * L * 0.5, ly = P0[1] + uy * L * 0.5;
    const la = smooth(unlerp(t, T.measure1 - 0.1, T.measure1 + 0.15));
    ctx.globalAlpha = a1 * la;
    ctx.font = '36px "Plex Mono"'; ctx.fillStyle = C.ink; ctx.textBaseline = 'middle';
    // sit the label to the right of the line
    ctx.fillText(km.toFixed(1) + ' KM', lx + 22, ly);
    ctx.restore();
  }
  // fold guide: the perpendicular bisector, drawn across the sheet
  const g = E.inOutCubic(unlerp(t, T.guide0, T.guide1));
  const gA = 1 - smooth(unlerp(t, T.fold0 + 0.05, T.fold0 + 0.35));
  if (g > 0 && gA > 0) {
    const M = FOLD.M, a = FOLD.a, span = 1300;
    ctx.save(); ctx.globalAlpha = gA;
    ctx.strokeStyle = C.ink; ctx.lineWidth = 2; ctx.setLineDash([14, 10]);
    ctx.beginPath(); ctx.moveTo(M[0] - a[0] * span * g, M[1] - a[1] * span * g); ctx.lineTo(M[0] + a[0] * span * g, M[1] + a[1] * span * g); ctx.stroke();
    ctx.setLineDash([]);
    // right-angle tick at the midpoint
    const ta = smooth(unlerp(t, T.guide0 + 0.2, T.guide1));
    if (ta > 0) {
      const n = FOLD.n, k = 18;
      ctx.globalAlpha = gA * ta; ctx.lineWidth = 2; ctx.strokeStyle = C.ink;
      ctx.beginPath();
      ctx.moveTo(M[0] + a[0] * k, M[1] + a[1] * k);
      ctx.lineTo(M[0] + a[0] * k - n[0] * k, M[1] + a[1] * k - n[1] * k);
      ctx.lineTo(M[0] - n[0] * k, M[1] - n[1] * k);
      ctx.stroke();
    }
    ctx.restore();
  }
}

function drawCrease(ctx, t) {
  const a = smooth(unlerp(t, T.unfold1 - 0.25, T.unfold1 + 0.2));
  if (a <= 0) return;
  const M = FOLD.M, d = FOLD.a, n = FOLD.n, span = 1500;
  ctx.save(); ctx.globalAlpha = a;
  polyPath(ctx, SHEET); ctx.clip();
  ctx.lineWidth = Math.max(1.4, 1.5 / CAMK);
  ctx.strokeStyle = rgbStr(RGB.silver);
  ctx.beginPath(); ctx.moveTo(M[0] - d[0] * span, M[1] - d[1] * span); ctx.lineTo(M[0] + d[0] * span, M[1] + d[1] * span); ctx.stroke();
  ctx.strokeStyle = rgbStr(RGB.white, 0.9); ctx.lineWidth = Math.max(1.2, 1.2 / CAMK);
  const o = Math.max(1.4, 1.4 / CAMK);
  ctx.beginPath(); ctx.moveTo(M[0] - d[0] * span + n[0] * o, M[1] - d[1] * span + n[1] * o); ctx.lineTo(M[0] + d[0] * span + n[0] * o, M[1] + d[1] * span + n[1] * o); ctx.stroke();
  ctx.restore();
}

// ---------------------------------------------------------------- frame
function draw(ctx, t) {
  const phi = foldPhi(t);
  const clearA = 1;
  const onFlap = t >= T.fold1 - 0.02;          // traveller rides the summit from the landing on
  const tr = pointAt(driveS(t) + hesitate(t));

  // table
  ctx.fillStyle = C.ink; ctx.fillRect(0, 0, W, H);
  // camera: at the end we pull back and see the whole map as an object
  const z = E.inOutCubic(unlerp(t, T.zoom0, T.zoom1));
  const k = lerp(1, ZOOM.k, z);
  ctx.save();
  ctx.translate(lerp(540, ZOOM.cx, z), lerp(960, ZOOM.cy, z)); ctx.scale(k, k); ctx.translate(-540, -960);
  CAMK = k;

  // base half of the sheet
  const basePoly = clipPoly(SHEET, false);
  ctx.save();
  if (phi === 0) {
    // flat: the whole sheet, printed directly (no seam at the fold line)
    polyPath(ctx, SHEET); ctx.fillStyle = C.paper; ctx.fill();
    drawMemory(ctx, t);
    drawPrint(ctx, ID, 'all', { roadA: clearA, contourA: clearA });
    drawCrease(ctx, t);
    drawRing(ctx, ID, 1, false);
  } else {
    polyPath(ctx, basePoly); ctx.fillStyle = C.paper; ctx.fill();
    polyPath(ctx, basePoly); ctx.clip();
    drawPrint(ctx, ID, 'base', { roadA: clearA, contourA: clearA });
    drawCrease(ctx, t);
  }
  ctx.restore();

  // traveller on the base (before it hitches a ride)
  if (!onFlap) drawDisc(ctx, ID, tr[0], tr[1], TRAV_R, C.ink);
  if (phi === 0 && onFlap) drawDisc(ctx, ID, SUMMIT.x, SUMMIT.y, TRAV_R, C.ink);

  if (phi !== 0) {
    // flap shadow on the base (soft, low)
    const flapPoly = clipPoly(SHEET, true);
    const lift = Math.sin(phi);
    if (lift > 0.01) {
      ctx.save();
      polyPath(ctx, basePoly); ctx.clip();
      const sh = flapPoly.map(p => { const q = proj3(p, phi); return [q[0] + q[2] * 0.10, q[1] + q[2] * 0.16]; });
      ctx.filter = `blur(${(10 + 26 * lift).toFixed(1)}px)`;
      polyPath(ctx, sh); ctx.fillStyle = rgbStr(RGB.ink, 0.10 * lift + 0.04 * (phi > 2.9 ? 1 : 0));
      ctx.fill();
      ctx.filter = 'none';
      ctx.restore();
    }
    // the flap itself
    const map = p => P(p, phi);
    const scr = flapPoly.map(map);
    const front = signedArea(scr) * signedArea(flapPoly) > 0;
    ctx.save();
    polyPath(ctx, scr);
    // shading: the front darkens slightly as it turns from the light, the back is a touch cooler
    const shadeF = mixRGB(RGB.paper, RGB.mist, clamp(Math.sin(phi) * 0.9));
    const shadeB = mixRGB(RGB.mist, RGB.paper, clamp(Math.abs(Math.cos(phi)) * 0.55));
    ctx.fillStyle = rgbStr(front ? shadeF : shadeB); ctx.fill();
    if (front) { const mA = smooth(unlerp(t, T.unfold1 - 0.2, T.settle1)); if (mA > 0) { ctx.fillStyle = rgbStr(RGB.mist, 0.38 * mA); ctx.fill(); } }
    ctx.clip();
    if (front) {
      drawPrint(ctx, map, 'flap', { roadA: clearA, contourA: clearA });
      drawRing(ctx, map, 1, false);
      if (onFlap) drawDisc(ctx, map, SUMMIT.x, SUMMIT.y, TRAV_R, C.ink);
    } else {
      // show-through: the print, reversed, at a whisper
      drawPrint(ctx, map, 'flap', { roadA: clearA, contourA: clearA, ghost: true });
      drawRing(ctx, map, 1, true);
      // the traveller under the paper, when the flap lies on it
      if (phi > 2.6) {
        const g = smooth(remap(phi, 2.6, Math.PI));
        ctx.fillStyle = rgbStr(RGB.ink, 0.34 * g);
        ctx.beginPath(); ctx.arc(TRAV_STOP[0], TRAV_STOP[1], TRAV_R, 0, Math.PI * 2); ctx.fill();
      }
    }
    ctx.restore();
    // crisp edge along the fold while the flap stands
    ctx.save();
    ctx.strokeStyle = rgbStr(RGB.silver, 0.8 * Math.sin(phi)); ctx.lineWidth = 1.2;
    const M = FOLD.M, d = FOLD.a;
    ctx.beginPath(); ctx.moveTo(M[0] - d[0] * 1500, M[1] - d[1] * 1500); ctx.lineTo(M[0] + d[0] * 1500, M[1] + d[1] * 1500); ctx.stroke();
    ctx.restore();
  }

  drawMeasure(ctx, t);
  ctx.restore();
  drawHUDText(ctx, t);
  drawLockup(ctx, t);
}
let CAMK = 1;
function drawCreaseFlat(ctx, t) { drawCrease(ctx, t); }
// once folded, the flap side keeps the faintest change of plane
function drawMemory(ctx, t) {
  const a = smooth(unlerp(t, T.unfold1 - 0.2, T.settle1));
  if (a <= 0) return;
  ctx.save();
  polyPath(ctx, clipPoly(SHEET, true));
  ctx.fillStyle = rgbStr(RGB.mist, 0.38 * a); ctx.fill();
  ctx.restore();
}

function drawHUDText(ctx, t) {
  const km = hudKm(t);
  const snap = t >= T.fold1 - 0.12;
  const hudA = 1 - smooth(unlerp(t, T.hud0, T.hud1));
  if (hudA <= 0) return;
  ctx.save(); ctx.globalAlpha = hudA;
  ctx.fillStyle = C.ink;
  ctx.font = '58px "Plex Mono Medium"'; ctx.textBaseline = 'alphabetic';
  const xr = 984, y = 1640;
  const str = km.toFixed(1);
  ctx.font = '30px "Plex Mono"';
  const wk = ctx.measureText('KM').width;
  ctx.fillStyle = C.graphite; ctx.fillText('KM', xr - wk, y);
  ctx.font = '58px "Plex Mono Medium"'; ctx.fillStyle = C.ink;
  const w = ctx.measureText(str).width;
  ctx.fillText(str, xr - wk - 14 - w, y);
  // the line, on the meter's baseline
  const la = smooth(unlerp(t, T.line0, T.line1));
  if (la > 0) {
    ctx.globalAlpha = hudA * la;
    ctx.font = '48px "Archivo Regular"';
    // a paper halo knocks the road out behind the label, the way a map sets its type
    ctx.lineJoin = 'round'; ctx.lineWidth = 22; ctx.strokeStyle = C.paper;
    ctx.strokeText('The road was a suggestion.', 96, y);
    ctx.fillStyle = C.ink;
    ctx.fillText('The road was a suggestion.', 96, y);
  }
  ctx.restore();
}

function drawLockup(ctx, t) {
  const a = smooth(unlerp(t, T.lock0, T.lock1));
  if (a <= 0) return;
  const s = 1.3;
  const vb = LOCKUP.vb;
  const cx = 540, cy = 1302;
  ctx.save(); ctx.globalAlpha = a;
  ctx.translate(cx - (vb.x + vb.w / 2) * s, cy - (vb.y + vb.h / 2) * s);
  ctx.scale(s, s);
  ctx.fillStyle = LOCKUP.fill; ctx.fill(LOCKUP.path);
  ctx.restore();
}

function blurAt(t) {
  if ((t > T.fold0 && t < T.fold1 + 0.05) || (t > T.unfold0 && t < T.unfold1) || (t > T.zoom0 && t < T.zoom1)) return 14;
  return 6;
}

function drawCover(ctx) { draw(ctx, T.end - 0.2); }

module.exports = { duration, setup, draw, drawCover, blurAt, T,
  _dbg: () => ({ ROAD, CUM, DRIVE, S_STOP, TRAV_STOP, FOLD }) };

// ---------------------------------------------------------------- sound data
function soundTrack(fps) {
  const n = Math.ceil(duration * fps);
  const speed = [], flap = [], zoom = [];
  const ev = [];
  let lastKm = null;
  const sub = 8;
  for (let f = 0; f < n * sub; f++) {
    const t = f / (fps * sub);
    const km = hudKm(t).toFixed(1);
    if (lastKm !== null && km !== lastKm && t < T.fold0) ev.push({ t, type: 'meter' });
    lastKm = km;
  }
  let landed = false;
  for (let f = 0; f < n; f++) {
    const t = f / fps, dt = 1 / fps;
    const sp = Math.abs(driveS(t + dt / 2) + hesitate(t + dt / 2) - driveS(t - dt / 2) - hesitate(t - dt / 2)) / dt;
    speed.push(sp);
    flap.push(Math.abs(foldPhi(t + dt / 2) - foldPhi(t - dt / 2)) / dt);
    zoom.push(Math.abs(E.inOutCubic(unlerp(t + dt / 2, T.zoom0, T.zoom1)) - E.inOutCubic(unlerp(t - dt / 2, T.zoom0, T.zoom1))) / dt);
    if (!landed && t > T.fold0 && foldPhi(t) >= Math.PI * 0.995) { landed = true; ev.push({ t, type: 'land' }); }
  }
  ev.push({ t: T.stop, type: 'stop' }, { t: T.stop + 0.30, type: 'creep' }, { t: T.stop + 0.60, type: 'creepback' },
    { t: T.measure0, type: 'measure' }, { t: T.measure1, type: 'label' }, { t: T.guide0, type: 'guide' },
    { t: T.lift0, type: 'lift' }, { t: T.fold0, type: 'fold' }, { t: T.fold1 - 0.12, type: 'zero' },
    { t: T.unfold0, type: 'unfold' }, { t: T.unfold1, type: 'unfolded' }, { t: T.zoom0, type: 'zoom' },
    { t: T.lock0, type: 'lockup' }, { t: T.line0, type: 'line' });
  // hairpin apexes: curvature peaks along the drive
  let prevK = 0, rising = false;
  for (let f = 0; f < Math.round(T.stop * fps); f++) {
    const t = f / fps, i = pointAt(driveS(t))[2], k = curvatureAt(i);
    if (k > 0.012 && k < prevK && rising) ev.push({ t, type: 'hairpin' });
    rising = k > prevK; prevK = k;
  }
  ev.sort((a, b) => a.t - b.t);
  return { duration, fps, events: ev, speed, flap, zoom };
}
module.exports.soundTrack = soundTrack;
