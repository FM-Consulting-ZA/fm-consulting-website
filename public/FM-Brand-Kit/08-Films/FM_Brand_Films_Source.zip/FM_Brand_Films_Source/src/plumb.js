// FILM 1 — PLUMB
// A heavy bar appears to swing. It never moves. The room does.
//
// World units are the FM primary mark's own units (w = 10). The bar is the
// mark's spine exactly (x 87–97, y 54–181); the nail sits at the head's centre
// (92, 17), so the thread passes through the head's aperture when the mark lands.
'use strict';
const { C, RGB, loadLogo, clamp, lerp, remap, unlerp, smooth, smoother, E, DEG,
  mixRGB, rgbStr, trackedText, Path2D } = require('./common');

const T = {
  // (scene time) swing extremes: + at 0.25, 2.25, 4.25, 6.25 · − at 1.25, 3.25, 5.25, 7.25
  // a ball teeters (4.1), later tips over the open end (6.15) and falls.
  // At the next zero-crossing (6.75) the bar stops dead at vertical — and the room keeps going.
  rev0: 6.60, rev1: 6.92,
  stop: 6.75,              // the swap: bar arrives at vertical, time all but holds
  room0: 6.78, room1: 7.10, // ROOM readout arrives and starts counting the room's tilt
  zoom0: 6.88, zoom1: 8.10,
  decay0: 7.25,            // room swing starts to die
  level: 10.40,            // room level
  line0: 10.05, line1: 10.40, lineOut0: 11.45, lineOut1: 11.75,   // "It was never the line."
  fade0: 11.55, fade1: 12.35,
  expand0: 11.60, expand1: 12.50,
  cut: 13.10,              // mark lands
  thread0: 13.50, thread1: 14.10,
  lock0: 14.05, lock1: 15.35,
  true0: 15.50, true1: 16.10,
  end: 17.90,
};
const OFFSET = 1.40;       // the film opens 1.4 s into the swing: already in motion, sooner to the event

// ---------------------------------------------------------------- time warp
// A held breath: the film slows to 35% as the ball goes over the edge, and
// recovers as the frame lets go. All timings above are in scene time.
const WARP = { a: 5.90 - OFFSET, b: 6.06 - OFFSET, c: 6.95 - OFFSET, d: 7.45 - OFFSET, depth: 0.60 };
// …and a deeper hold on the exact frame the bar arrives at vertical, so the swap registers
const DIP = { depth: 0.78, w: 0.15 };
let TC = 5.5;
function speedBase(tr) {
  if (tr <= WARP.a || tr >= WARP.d) return 1;
  let k = tr < WARP.b ? smooth((tr - WARP.a) / (WARP.b - WARP.a))
    : tr < WARP.c ? 1 : 1 - smooth((tr - WARP.c) / (WARP.d - WARP.c));
  return 1 - WARP.depth * k;
}
function speed(tr) { return speedBase(tr) * (1 - DIP.depth * Math.exp(-(((tr - TC) / DIP.w) ** 2))); }
const WH = 1 / 2000; let WTAB = [0];
function buildWarp() { WTAB = [0]; for (let i = 1; i < 30 / WH; i++) WTAB.push(WTAB[i - 1] + speed((i - 0.5) * WH) * WH); }
function warp(tr) {
  if (tr <= 0) return OFFSET + tr;
  return OFFSET + warp0(tr);
}
function warp0(tr) {
  const f = tr / WH, i = Math.floor(f);
  if (i + 1 >= WTAB.length) return WTAB[WTAB.length - 1] + (tr - (WTAB.length - 1) * WH);
  return lerp(WTAB[i], WTAB[i + 1], f - i);
}
function unwarp(ts) { // scene -> real
  if (ts <= OFFSET) return ts - OFFSET;
  let lo = 0, hi = 30;
  for (let k = 0; k < 50; k++) { const m = (lo + hi) / 2; if (warp(m) < ts) lo = m; else hi = m; }
  return (lo + hi) / 2;
}
for (let k = 0; k < 5; k++) { buildWarp(); TC = unwarp(T.stop); }
buildWarp();
const duration = Math.round(unwarp(T.end) * 30) / 30;

const N = { x: 92, y: 17 };               // nail = head centre
const BAR = { x0: 87, x1: 97, y0: 54, y1: 181 };
const LEDGE = { x0: 24, x1: 176, y0: 212, y1: 222 };
const STOP = { x0: 166, x1: 176, y0: 190, y1: 212 };
const BALL_R = 12;
const PANEL = { cx: 92, cy: 139, w: 204, h: 363 };   // 9:16, room coords — exactly covers the opening frame
const S_A = 5.4, S_WIDE = 3.3, S_LOCK = 2.2;
const ANCHOR_A = 300;
const G = 1600;                            // units / s²
const OMEGA = 2 * Math.PI / 2.0, T_REF = -0.25;

// ---------------------------------------------------------------- room angle
function amp(t) {
  const grow = lerp(10 * DEG, 20 * DEG, smooth((t + 3) / 8.9));
  if (t <= T.decay0) return grow;
  const a = 20 * DEG * Math.exp(-(t - T.decay0) / 0.95);
  return a * (1 - smooth((t - (T.level - 1.4)) / 1.4));
}
function theta(t) {
  if (t >= T.level) return 0;
  return amp(t) * Math.sin(OMEGA * (t - T_REF));
}

// ---------------------------------------------------------------- ball simulation
// Balls roll on the ledge under the room's tilt (rolling sphere, a = 5/7 g sinθ).
// At the open end a ball pivots over the corner (so it can teeter and recover),
// and past ~50° it leaves and falls in WORLD space — straight down, always.
let SIM = null;
function simulate(fps) {
  const dt = 1 / 2400, t0 = -4, t1 = T.end;
  const XC = LEDGE.x0;
  const balls = [{ x: 60 }, { x: 86 }, { x: 112 }].map((b, i) => ({ ...b, v: 0, rot: i * 1.7, mode: 'ledge', psi: 0, dpsi: 0, wx: 0, wy: 0, wvx: 0, wvy: 0 }));
  const frames = [], events = [];
  const nF = Math.ceil((t1 - t0) * fps) + 2;
  const stepsPerFrame = Math.round(1 / (fps * dt));
  const K = 5 / 7, damp = 1.6, eWall = 0.42, eBall = 0.55;
  let t = t0;
  const snap = () => balls.map(b => {
    let x = b.x, y = LEDGE.y0 - BALL_R;
    if (b.mode === 'corner') { x = XC - BALL_R * Math.sin(b.psi); y = LEDGE.y0 - BALL_R * Math.cos(b.psi); }
    return { x, y, v: b.mode === 'ledge' ? b.v : -BALL_R * b.dpsi, rot: b.rot, state: b.mode === 'fall' || b.mode === 'gone' ? b.mode : 'ledge', wx: b.wx, wy: b.wy };
  });
  for (let f = 0; f < nF; f++) {
    frames.push({ t, balls: snap() });
    for (let s = 0; s < stepsPerFrame; s++) {
      const th = theta(t);
      for (const b of balls) {
        if (b.mode === 'ledge') {
          const a = K * G * Math.sin(th) - damp * b.v;
          b.v += a * dt; b.x += b.v * dt; b.rot += (b.v / BALL_R) * dt;
          if (b.x > STOP.x0 - BALL_R) {
            if (Math.abs(b.v) > 4) events.push({ t, type: 'clack', v: Math.abs(b.v), x: b.x });
            b.x = STOP.x0 - BALL_R; b.v = -eWall * b.v;
          }
          if (b.x < XC) { b.mode = 'corner'; b.psi = 0; b.dpsi = -b.v / BALL_R; b.tin = t; events.push({ t, type: 'edge', v: Math.abs(b.v) }); }
        } else if (b.mode === 'corner') {
          const dd = K * (G / BALL_R) * Math.sin(b.psi - th) - damp * b.dpsi;
          b.dpsi += dd * dt; b.psi += b.dpsi * dt; b.rot -= b.dpsi * dt;
          if (b.psi < 0) { b.mode = 'ledge'; b.x = XC; b.v = -b.dpsi * BALL_R; events.push({ t, type: 'teeter' }); }
          else if (b.psi > 50 * DEG) {
            b.mode = 'fall';
            events.push({ t, type: 'drop', v: Math.abs(b.dpsi * BALL_R) });
            const c = Math.cos(th), si = Math.sin(th);
            const rx = XC - BALL_R * Math.sin(b.psi) - N.x, ry = LEDGE.y0 - BALL_R * Math.cos(b.psi) - N.y;
            const vx = -BALL_R * Math.cos(b.psi) * b.dpsi, vy = BALL_R * Math.sin(b.psi) * b.dpsi;
            const om = (theta(t + 1e-3) - theta(t - 1e-3)) / 2e-3;
            b.wx = N.x + c * rx - si * ry; b.wy = N.y + si * rx + c * ry;
            b.wvx = c * vx - si * vy - om * (b.wy - N.y);
            b.wvy = si * vx + c * vy + om * (b.wx - N.x);
            b.spin = -b.dpsi;
          }
        } else if (b.mode === 'fall') {
          b.wvy += G * dt; b.wx += b.wvx * dt; b.wy += b.wvy * dt; b.rot += b.spin * dt;
          if (b.wy > 900) b.mode = 'gone';
        }
      }
      // ball–ball contacts (on the ledge only)
      const on = balls.filter(b => b.mode === 'ledge').sort((a, b) => a.x - b.x);
      for (let i = 0; i + 1 < on.length; i++) {
        const a = on[i], b = on[i + 1];
        const gap = b.x - a.x - 2 * BALL_R;
        if (gap < 0) {
          const rel = a.v - b.v;
          if (rel > 0) {
            if (rel > 6) events.push({ t, type: 'click', v: rel, x: (a.x + b.x) / 2 });
            const va = a.v, vb = b.v;
            a.v = ((1 - eBall) * va + (1 + eBall) * vb) / 2;
            b.v = ((1 + eBall) * va + (1 - eBall) * vb) / 2;
          }
          a.x += gap / 2; b.x -= gap / 2;
        }
      }
      t += dt;
    }
  }
  return { t0, fps, frames, events };
}
function ballsAt(t) {
  const fi = (t - SIM.t0) * SIM.fps;
  const i = Math.max(0, Math.min(SIM.frames.length - 2, Math.floor(fi)));
  const u = fi - i, A = SIM.frames[i].balls, B = SIM.frames[i + 1].balls;
  return A.map((a, k) => {
    const b = B[k];
    return { x: lerp(a.x, b.x, u), y: lerp(a.y, b.y, u), rot: lerp(a.rot, b.rot, u), v: a.v, state: a.state,
      wx: lerp(a.wx, b.wx, u), wy: lerp(a.wy, b.wy, u) };
  });
}

// ---------------------------------------------------------------- setup
let LOGO, LOCKUP;
function setup(opts) {
  LOGO = loadLogo('fm-primary');                       // ink on paper, primary cut
  LOCKUP = loadLogo('fm-lockup-stacked-descriptor');   // same mark geometry + wordmark
  SIM = simulate(240);
  const drops = SIM.events.filter(e => e.type === 'drop');
  if (!opts.quiet) console.error('[plumb] events', SIM.events.filter(e => e.type !== 'click' && e.type !== 'clack' && e.t > 0).map(d => d.type + '@' + d.t.toFixed(3)).join(', '), '| clacks', SIM.events.filter(e => e.type === 'clack' && e.t > 0 && e.t < 6.5).length);
}

// ---------------------------------------------------------------- camera
function camera(t) {
  const z = E.inOutCubic(unlerp(t, T.zoom0, T.zoom1));
  const r = smooth(unlerp(t, T.rev0, T.rev1));
  const lk = E.inOutCubic(unlerp(t, T.lock0, T.lock1));
  const s = lerp(lerp(S_A, S_WIDE, z), S_LOCK, lk);
  // lockup centre in mark units (from the stacked-descriptor viewBox)
  const L = { x: LOCKUP.vb.x + LOCKUP.vb.w / 2, y: LOCKUP.vb.y + LOCKUP.vb.h / 2 };
  let tx = lerp(N.x, PANEL.cx, z), ty = lerp(N.y, PANEL.cy, z);
  tx = lerp(tx, L.x, lk); ty = lerp(ty, L.y - 8, lk);
  const ax = 540, ay = lerp(ANCHOR_A, 960, z);
  return { s, tx, ty, ax, ay, rot: theta(t) * (1 - r), r, z };
}
function applyCam(ctx, cam) {
  ctx.translate(cam.ax, cam.ay);
  ctx.rotate(-cam.rot);
  ctx.scale(cam.s, cam.s);
  ctx.translate(-cam.tx, -cam.ty);
}

// ---------------------------------------------------------------- drawing
function drawBall(ctx, x, y, rot, alpha) {
  ctx.save();
  ctx.translate(x, y); ctx.rotate(rot);
  ctx.globalAlpha *= alpha;
  ctx.fillStyle = C.ink;
  ctx.beginPath(); ctx.arc(0, 0, BALL_R, 0, Math.PI * 2); ctx.fill();
  // a paper slit so the roll is legible (a radius, like a clock hand — not an eye)
  ctx.fillStyle = C.paper;
  ctx.fillRect(-BALL_R * 0.05, -BALL_R * 0.86, BALL_R * 0.10, BALL_R * 0.58);
  ctx.restore();
}

function drawArc(ctx, alpha) {
  if (alpha <= 0) return;
  ctx.save(); ctx.globalAlpha *= alpha;
  const R = 31;
  ctx.strokeStyle = C.graphite; ctx.lineWidth = 0.32;
  ctx.beginPath(); ctx.arc(N.x, N.y, R, (90 - 40) * DEG, (90 + 40) * DEG); ctx.stroke();
  for (let a = -40; a <= 40; a += 5) {
    const major = a % 15 === 0;
    const L = a === 0 ? 5 : major ? 3.4 : 1.8;
    const ang = (90 - a) * DEG;
    const c = Math.cos(ang), s = Math.sin(ang);
    ctx.lineWidth = a === 0 ? 0.55 : 0.32;
    ctx.strokeStyle = a === 0 ? C.ink : C.graphite;
    ctx.beginPath(); ctx.moveTo(N.x + c * R, N.y + s * R); ctx.lineTo(N.x + c * (R + L), N.y + s * (R + L)); ctx.stroke();
    if (major && a !== 0) {
      ctx.save();
      ctx.fillStyle = C.graphite; ctx.font = '2.5px "Plex Mono"'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.translate(N.x + c * (R + 7.2), N.y + s * (R + 7.2));
      ctx.fillText(String(Math.abs(a)), 0, 0);
      ctx.restore();
    }
  }
  ctx.restore();
}

// room-fixed version (used on the cover only)
function drawReadout(ctx, alpha, t) {
  if (alpha <= 0) return;
  ctx.save(); ctx.globalAlpha *= alpha;
  ctx.fillStyle = C.ink;
  ctx.font = '10.5px "Plex Mono Medium"'; ctx.textBaseline = 'alphabetic';
  ctx.fillText('0.0°', 106, 16);
  ctx.fillStyle = C.graphite; ctx.font = '4.2px "Plex Mono"';
  trackedText(ctx, 'LINE', 106.4, 3.5, 4.2, 0.24);
  ctx.restore();
}

// ---------------------------------------------------------------- the instrument (screen-fixed)
// LINE never changes. ROOM arrives the moment the bar stops, and counts the room's real tilt.
// Each glyph is ink where it sits over the paper room and paper where it sits over the ink.
const HUD = { xr: 984, y1: 300, y2: 386, label: 24, value: 58 };
const fmtDeg = a => (Math.abs(a) < 0.05 ? '' : a > 0 ? '+' : '−') + Math.abs(a).toFixed(1) + '°';
function hudRow(ctx, label, value, y, onInk) {
  ctx.font = `${HUD.value}px "Plex Mono Medium"`;
  const wv = ctx.measureText(value).width;
  ctx.fillStyle = onInk ? C.paper : C.ink;
  ctx.fillText(value, HUD.xr - wv, y);
  ctx.font = `${HUD.label}px "Plex Mono"`;
  ctx.fillStyle = onInk ? C.silver : C.graphite;
  trackedText(ctx, label, HUD.xr - 262, y, HUD.label, 0.24, 'right');
}
function roomToScreen(cam, th, x, y) {
  // room -> world (rotate about the nail) -> screen (camera)
  const c = Math.cos(th), si = Math.sin(th);
  const wx = N.x + c * (x - N.x) - si * (y - N.y), wy = N.y + si * (x - N.x) + c * (y - N.y);
  const dx = (wx - cam.tx) * cam.s, dy = (wy - cam.ty) * cam.s;
  const cr = Math.cos(-cam.rot), sr = Math.sin(-cam.rot);
  return [cam.ax + cr * dx - sr * dy, cam.ay + sr * dx + cr * dy];
}
function drawHUD(ctx, t, cam, th, a, tReal) {
  if (a <= 0) return;
  // the instrument samples at 15 Hz on whole frames, so digits stay crisp under motion blur
  const fr = Math.round(tReal * 30), tS = warp(Math.floor(fr / 2) * 2 / 30);
  const roomA = smooth(unlerp(t, T.room0, T.room1));
  const g = E.inOutCubic(unlerp(t, T.expand0, T.expand1));
  const w = lerp(PANEL.w, 4000, g), h = lerp(PANEL.h, 7000, g);
  const pts = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([sx, sy]) => roomToScreen(cam, th, PANEL.cx + sx * w / 2, PANEL.cy + sy * h / 2));
  for (const onInk of [false, true]) {
    ctx.save();
    ctx.beginPath();
    if (onInk) ctx.rect(-10, -10, 1100, 1940);
    pts.forEach((q, i) => i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1])); ctx.closePath();
    ctx.clip(onInk ? 'evenodd' : 'nonzero');
    ctx.globalAlpha *= a; ctx.textBaseline = 'alphabetic';
    hudRow(ctx, 'LINE', '0.0°', HUD.y1, onInk);
    if (roomA > 0) { ctx.globalAlpha *= roomA; hudRow(ctx, 'ROOM', fmtDeg(theta(tS) / DEG), HUD.y2, onInk); }
    ctx.restore();
  }
}

// the line, set on the room once it's level
function drawLine(ctx, t) {
  const a = smooth(unlerp(t, T.line0, T.line1)) * (1 - smooth(unlerp(t, T.lineOut0, T.lineOut1)));
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha *= a;
  ctx.fillStyle = C.ink; ctx.textBaseline = 'alphabetic';
  ctx.font = '15.5px "Archivo Regular"';
  ctx.fillText('It was never the line.', LEDGE.x0, 262);
  ctx.restore();
}

function drawRoom(ctx, t, th, contentAlpha, panelGrow) {
  ctx.save();
  ctx.translate(N.x, N.y); ctx.rotate(th); ctx.translate(-N.x, -N.y);
  // paper panel (grows to infinite paper at the end)
  const g = panelGrow;
  const w = lerp(PANEL.w, 4000, g), h = lerp(PANEL.h, 7000, g);
  ctx.fillStyle = C.paper;
  ctx.fillRect(PANEL.cx - w / 2, PANEL.cy - h / 2, w, h);

  drawArc(ctx, contentAlpha);
  drawLine(ctx, t);
  if (contentAlpha > 0) {
    ctx.save(); ctx.globalAlpha *= contentAlpha;
    ctx.fillStyle = C.ink;
    ctx.fillRect(LEDGE.x0, LEDGE.y0, LEDGE.x1 - LEDGE.x0, LEDGE.y1 - LEDGE.y0);
    ctx.fillRect(STOP.x0, STOP.y0, STOP.x1 - STOP.x0, STOP.y1 - STOP.y0);
    ctx.restore();
    for (const b of ballsAt(t)) if (b.state === 'ledge') drawBall(ctx, b.x, b.y, b.rot, contentAlpha);
  }
  ctx.restore();
}

function drawPlumb(ctx, t, threadAlpha) {
  // world-fixed, dead vertical. Always.
  if (threadAlpha > 0) {
    ctx.save(); ctx.globalAlpha *= threadAlpha;
    ctx.fillStyle = C.ink;
    ctx.fillRect(N.x - 0.3, N.y, 0.6, BAR.y0 - N.y + 0.5);
    ctx.beginPath(); ctx.arc(N.x, N.y, 1.7, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
  ctx.fillStyle = C.ink;
  ctx.fillRect(BAR.x0, BAR.y0, BAR.x1 - BAR.x0, BAR.y1 - BAR.y0);
}

function draw(ctx, tReal, opts) {
  const t = warp(tReal);
  const W = opts.W, H = opts.H;
  const th = theta(t);
  const cam = camera(t);
  // ink void (the world beyond the room)
  ctx.fillStyle = C.ink; ctx.fillRect(0, 0, W, H);

  const contentAlpha = 1 - smooth(unlerp(t, T.fade0, T.fade1));
  const grow = E.inOutCubic(unlerp(t, T.expand0, T.expand1));
  const afterCut = t >= T.cut;
  const threadAlpha = afterCut ? 1 - smooth(unlerp(t, T.thread0, T.thread1)) : 1;

  ctx.save();
  applyCam(ctx, cam);
  drawRoom(ctx, t, th, contentAlpha, grow);

  // falling balls live in the world, not the room
  for (const b of ballsAt(t)) if (b.state === 'fall') drawBall(ctx, b.wx, b.wy, b.rot, 1);

  if (!afterCut) {
    drawPlumb(ctx, t, threadAlpha);
  } else {
    // the mark lands: genuine primary artwork, ink, same units — the bar is its spine
    drawPlumbThreadOnly(ctx, threadAlpha);
    ctx.fillStyle = C.ink;
    ctx.fill(LOGO.path);
    const wm = smooth(unlerp(t, T.lock0 + 0.80, T.lock1 + 0.25));   // only once the lockup fits the frame
    if (wm > 0) {
      ctx.save(); ctx.globalAlpha *= wm;
      ctx.fillStyle = C.ink; ctx.fill(LOCKUP.path);
      ctx.restore();
    }
    // the readout returns under the lockup: the one figure that never changed
    const tr = smooth(unlerp(t, T.true0, T.true1));
    if (tr > 0) {
      const cx = LOCKUP.vb.x + LOCKUP.vb.w / 2, y = LOCKUP.vb.y + LOCKUP.vb.h + 70;
      ctx.save(); ctx.globalAlpha *= tr;
      ctx.textBaseline = 'alphabetic'; ctx.fillStyle = C.graphite;
      ctx.font = '7.6px "Plex Mono"';
      const wTrue = trackedText(ctx, 'TRUE', -1e4, -1e4, 7.6, 0.24);
      ctx.font = '15.5px "Plex Mono"';
      const wNum = ctx.measureText('0.0°').width;
      const gap = 6.5, total = wTrue + gap + wNum, x0 = cx - total / 2;
      ctx.font = '7.6px "Plex Mono"'; trackedText(ctx, 'TRUE', x0, y, 7.6, 0.24);
      ctx.fillStyle = C.ink; ctx.font = '15.5px "Plex Mono"'; ctx.fillText('0.0°', x0 + wTrue + gap, y);
      ctx.restore();
    }
  }
  ctx.restore();
  drawHUD(ctx, t, cam, th, contentAlpha, tReal);
}
function drawPlumbThreadOnly(ctx, a) {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha *= a; ctx.fillStyle = C.ink;
  // thread slides up out of the aperture as it fades
  ctx.fillRect(N.x - 0.3, N.y, 0.6, BAR.y0 - N.y + 0.5);
  ctx.beginPath(); ctx.arc(N.x, N.y, 1.7, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

function blurAt(tReal) {
  const t = warp(tReal);
  if ((t > T.zoom0 - 0.2 && t < T.zoom1 + 0.1) || (t > T.expand0 && t < T.expand1)) return 12;
  return t < T.level + 0.2 || (t > T.lock0 && t < T.lock1 + 0.1) ? 6 : 1;
}

// ---------------------------------------------------------------- sound data
function soundTrack(fps) {
  const ev = SIM.events.filter(e => e.t >= OFFSET && e.t <= T.end).map(e => ({ ...e, t: unwarp(e.t) }));
  const n = Math.ceil(duration * fps);
  const roll = [], creak = [], swing = [], spd = [];
  for (let f = 0; f < n; f++) {
    const t = warp(f / fps), dt = speed(f / fps) / fps;
    spd.push(speed(f / fps));
    const bs = ballsAt(t);
    roll.push(bs.map(b => b.state === 'ledge' ? Math.abs(b.v) : 0));
    const w = (theta(t + dt / 2) - theta(t - dt / 2)) / dt; // room angular velocity
    creak.push(Math.abs(w));
    const cam0 = camera(t - dt / 2), cam1 = camera(t + dt / 2);
    // on-screen angular speed of the bar
    const bar0 = -theta(t - dt / 2) * (1 - cam0.r), bar1 = -theta(t + dt / 2) * (1 - cam1.r);
    swing.push(Math.abs(bar1 - bar0) / dt);
  }
  for (const [k, ty] of [['rev0', 'reveal'], ['stop', 'stopdead'], ['cut', 'cut'], ['level', 'level'], ['lock0', 'lockup'], ['fade0', 'fade'], ['expand0', 'expand'], ['true0', 'true'], ['line0', 'line']])
    ev.push({ t: unwarp(T[k]), type: ty });
  ev.sort((a, b) => a.t - b.t);
  return { duration, fps, events: ev, roll, creak, swing, speed: spd };
}

// ---------------------------------------------------------------- cover
// The film's key image as a still: the room caught at a tilt, the bar dead vertical,
// on the ink field, with the reversed lockup beneath (same system as the Shortcut cover).
let LOCKUP_REV;
function drawCover(ctx, opts) {
  LOCKUP_REV = LOCKUP_REV || loadLogo('fm-lockup-stacked-descriptor-reverse');
  ctx.fillStyle = C.ink; ctx.fillRect(0, 0, 1080, 1920);
  const th = -13 * DEG, s = 2.35;
  ctx.save();
  ctx.translate(540, 660); ctx.scale(s, s); ctx.translate(-PANEL.cx, -PANEL.cy);
  // room at a tilt, balls resting against the low side of the ledge
  ctx.save();
  ctx.translate(N.x, N.y); ctx.rotate(th); ctx.translate(-N.x, -N.y);
  ctx.fillStyle = C.paper; ctx.fillRect(PANEL.cx - PANEL.w / 2, PANEL.cy - PANEL.h / 2, PANEL.w, PANEL.h);
  drawArc(ctx, 1); drawReadout(ctx, 1, 0);
  ctx.fillStyle = C.ink;
  ctx.fillRect(LEDGE.x0, LEDGE.y0, LEDGE.x1 - LEDGE.x0, LEDGE.y1 - LEDGE.y0);
  ctx.fillRect(STOP.x0, STOP.y0, STOP.x1 - STOP.x0, STOP.y1 - STOP.y0);
  drawBall(ctx, LEDGE.x0 + 1, LEDGE.y0 - BALL_R, 0.9, 1);
  drawBall(ctx, LEDGE.x0 + 1 + 2 * BALL_R, LEDGE.y0 - BALL_R, 2.6, 1);
  ctx.restore();
  drawPlumb(ctx, 0, 1);
  ctx.restore();
  const vb = LOCKUP_REV.vb, ls = 1.08;
  ctx.save();
  ctx.translate(540 - (vb.x + vb.w / 2) * ls, 1462 - (vb.y + vb.h / 2) * ls); ctx.scale(ls, ls);
  ctx.fillStyle = LOCKUP_REV.fill; ctx.fill(LOCKUP_REV.path);
  ctx.restore();
}

module.exports = { duration, setup, draw, drawCover, blurAt, soundTrack, T, warp, unwarp };
