# FM Consulting — brand films (source)

Two original vertical brand films for FM Consulting (Pty) Ltd, built entirely in code on the
brand kit v1.0: ink and paper only, Archivo / Archivo Expanded / IBM Plex Mono, and the
supplied, outlined logo files (paths are read verbatim from `assets/logo/*.svg`, never redrawn).

| Film | File | Length | Idea |
|---|---|---|---|
| 1 · PLUMB | `out/final/FM_Plumb_1080x1920.mp4` | 17.4 s | A heavy bar appears to swing. It never moves: the room does. The bar is the mark's spine. |
| 2 · SHORTCUT | `out/final/FM_Shortcut_1080x1920.mp4` | 15.8 s | A disc drives a mountain road, stops, measures, and folds the map so the summit lands on it. |

## Rebuild everything

```bash
bash build.sh            # needs node 18+, python3 (numpy, scipy, pillow), ffmpeg
```

## Change something

| You want to… | Edit |
|---|---|
| Retime a beat | the `T = { … }` table at the top of `src/plumb.js` / `src/shortcut.js` (seconds) |
| Change the Plumb swing, ball physics or slow-motion | `amp()`, `simulate()`, `WARP` in `src/plumb.js` |
| Change the road, the fold, or the end framing | `buildRoad()`, `foldPhi()`, `ZOOM` in `src/shortcut.js` |
| Adjust a sound | `src/sound.py`: one function per film; every cue is named |
| Preview a moment as a still | `node src/render.js --film plumb --stills 3.5,6.2 --outdir review` |
| Render a quick low-res animatic | `node src/render.js --film shortcut --out review/a.mp4 --w 540 --h 960 --sub 1 --preset veryfast` |

## How it's made

* **Picture:** `src/render.js` draws each frame with Skia (`@napi-rs/canvas`) in a 1080 × 1920 design space
  and pipes raw RGBA to FFmpeg (H.264 High, yuv420p, BT.709 tagged, 30 fps). Motion blur averages 6–14
  sub-frames across a 180° shutter.
* **Plumb:** the camera is locked to the room until the reveal, then to the world. The bar hangs from the
  head's centre, so the thread passes exactly through the aperture when the mark lands. The balls are a real
  rolling simulation (5/7 g sin θ, pivot-over-the-lip, free fall in world space).
* **Shortcut:** the sheet is a plane in 3D; the flap rotates about the perpendicular bisector of
  traveller → summit, so the summit lands on the traveller by construction. Every point is perspective-projected.
* **Sound:** `src/sound.py` synthesises everything from noise, filters and decaying modes. No samples, no
  libraries, no licences. Cues come from the animation (`--events`), so hits land on the frame. Mixed to about
  −16 LUFS integrated, ≤ −1.5 dBTP, static gain only (no loudness compression).

## Assets and rights

* Fonts: Archivo, Archivo Expanded, IBM Plex Mono from the FM kit, SIL Open Font Licence (licences in `assets/fonts`).
* Logos: unmodified FM kit SVGs (`assets/logo`). Positive primary on paper; `-reverse` artwork on ink.
* Audio: original synthesis, owned by FM Consulting. No third-party audio.

## Review tools

`src/review.py` (contact sheet + frame-difference report for flicker / jumps / dead air),
`src/audioviz.py` (spectrogram + level plot with cue markers), `src/contact.py`.
