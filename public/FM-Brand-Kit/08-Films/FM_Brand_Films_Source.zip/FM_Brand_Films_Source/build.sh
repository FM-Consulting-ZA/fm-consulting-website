#!/bin/bash
# Rebuild both films, their soundtracks and covers from source.
# Requires: node 18+, python3 with numpy + scipy + pillow, ffmpeg.
set -e
cd "$(dirname "$0")"
[ -d node_modules ] || npm install
mkdir -p out/final out/covers audio
for F in plumb shortcut; do
  N=$( [ $F = plumb ] && echo FM_Plumb || echo FM_Shortcut )
  node src/render.js --film $F --events audio/${F}_events.json          # frame-accurate sound cues
  python3 src/sound.py $F audio/${F}_events.json audio/${N}_mix.wav     # original synthesised soundtrack
  node src/render.js --film $F --out out/final/${F}_video.mp4 --sub 6   # 1080x1920, 30 fps, motion blur
  ./src/mux.sh out/final/${F}_video.mp4 audio/${N}_mix.wav out/final/${N}_1080x1920.mp4
  node src/render.js --film $F --cover out/covers/${N}_cover.png
done
echo "Done: out/final/*.mp4, out/covers/*.png"
