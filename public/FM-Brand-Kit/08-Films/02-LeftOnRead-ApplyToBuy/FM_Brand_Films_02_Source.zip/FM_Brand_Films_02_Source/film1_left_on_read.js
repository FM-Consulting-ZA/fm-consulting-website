// FILM 1 — LEFT ON READ   ("That is exactly the problem.")
// One mechanism: in this chat, empty space is waiting time. We scroll through
// two days of silence, step back to see the whole gap, and FM closes it.
'use strict';
const X = require('./lib/engine');
const { C, T, W, H, E, seg, lerp, clamp, rr, text, measure, wrap, ticks, drawLogo, spring } = X;
const { drawEndCard, LOCKUP_LAND } = require('./lib/endcard');

// ------------------------------------------------------------------ timing
const TL = {
  readIn: 0.70, lastSeen: 1.30,
  scroll0: 1.50, scroll1: 6.30,
  zoomOut0: 7.80, zoomOut1: 9.00,
  specIn: 8.55, fmIn: 8.75,
  strike: 9.75, newOwner: 9.98,
  collapse0: 10.30, collapse1: 11.20,
  zoomIn0: 11.30, zoomIn1: 12.10,
  booked: 13.10,
  expand0: 14.15, expand1: 14.85,
  duration: 18.55,
};

// ------------------------------------------------------------------ layout
const M = 80;                        // screen margin (clears platform UI rails)
const NOW = 1350;                    // screen y of the newest content (above the input bar)
const BUB = { size: T.s21, lead: 66, padX: 38, padT: 30, stampH: 46, r: 34, maxW: 660 };
const { ctx: mctx } = X.makeCtx();

function bubble(id, side, str, stamp, top, extra = {}) {
  const lines = wrap(mctx, str, 'ArchivoRegular', BUB.size, BUB.maxW - 2 * BUB.padX);
  const tw = Math.max(...lines.map(l => measure(mctx, l, 'ArchivoRegular', BUB.size)));
  const w = Math.max(tw, 170) + 2 * BUB.padX;
  const h = BUB.padT + lines.length * BUB.lead + BUB.stampH;
  const x = side === 'me' ? W - M - w : M;
  return { id, kind: 'bubble', side, str, lines, stamp, x, y: top, w, h, bottom: top + h, ...extra };
}
function pill(id, label, cy) {
  const w = measure(mctx, label, 'PlexMono', T.s12, 3) + 56;
  return { id, kind: 'pill', label, x: W / 2 - w / 2, y: cy - 28, w, h: 56, bottom: cy + 28 };
}

const L = {};
L.monday = pill('monday', 'MONDAY', 990);
L.enq = bubble('enq', 'me', 'Hi, can I get a quote? Need it done this week.', '09:14', 1036);
L.read = { y: L.enq.bottom + 40 };
L.hello = bubble('hello', 'me', 'Hello?', '11:40', L.enq.bottom + 380);
L.tue = pill('tue', 'TUESDAY', L.hello.bottom + 330);
L.found = bubble('found', 'me', 'All good, found someone else.', '16:02', L.tue.bottom + 360);
L.wed = pill('wed', 'WEDNESDAY', L.found.bottom + 90);
L.late = bubble('late', 'them', 'Hi! So sorry for the delay. Still keen?', '10:05', L.wed.bottom + 34);
L.fix = bubble('fix', 'them', 'Hi! Yes, we can. Thursday at 10:00?', '09:19', 0);
L.book = bubble('book', 'me', 'Perfect, book me in.', '09:20', 0);

const gapTop = L.read.y + 10;            // below "Read 09:14"
const gapBot = L.late.y;                 // top of the business reply
const MIN_GAP = 44;                      // compact spacing once fixed

// Camera: y offset of the world while scrolling. Keyframes are placed where
// each new message's bottom reaches the "now" line.
const camFor = el => el.bottom + 36 - NOW;
const KF = [
  [TL.scroll0, 0],
  [2.75, camFor(L.hello)],
  [3.25, camFor(L.hello) + 70],
  [4.55, camFor(L.found)],
  [5.45, camFor(L.found) + 60],
  [TL.scroll1, camFor(L.late)],
];
// Monotone cubic (Fritsch–Carlson): smooth, never overshoots.
function monotone(kf) {
  const n = kf.length, xs = kf.map(k => k[0]), ys = kf.map(k => k[1]);
  const h = [], d = [], m = new Array(n).fill(0);
  for (let i = 0; i < n - 1; i++) { h.push(xs[i + 1] - xs[i]); d.push((ys[i + 1] - ys[i]) / h[i]); }
  for (let i = 1; i < n - 1; i++) {
    if (d[i - 1] * d[i] <= 0) m[i] = 0;
    else m[i] = 3 * (h[i - 1] + h[i]) / ((2 * h[i] + h[i - 1]) / d[i - 1] + (h[i] + 2 * h[i - 1]) / d[i]);
  }
  return t => {
    if (t <= xs[0]) return ys[0];
    if (t >= xs[n - 1]) return ys[n - 1];
    let i = 0; while (t > xs[i + 1]) i++;
    const hh = h[i], s = (t - xs[i]) / hh;
    const h00 = 2 * s ** 3 - 3 * s ** 2 + 1, h10 = s ** 3 - 2 * s ** 2 + s, h01 = -2 * s ** 3 + 3 * s ** 2, h11 = s ** 3 - s ** 2;
    return h00 * ys[i] + h10 * hh * m[i] + h01 * ys[i + 1] + h11 * hh * m[i + 1];
  };
}
const camY = monotone(KF);

// Pop times: when the now line reaches each message.
const POP = {};
for (const el of [L.hello, L.tue, L.found, L.wed, L.late]) {
  const target = camFor(el);
  let tp = TL.scroll1;
  for (let t = TL.scroll0; t <= TL.scroll1; t += 1 / 600) if (camY(t) >= target - 1) { tp = t; break; }
  POP[el.id] = tp;
}

// Clock: minutes since Monday 00:00 as a function of the now line (world y).
const CLOCK = [
  [L.read.y, 9 * 60 + 14],
  [L.hello.bottom + 36, 11 * 60 + 40],
  [L.tue.bottom, 1440],
  [L.found.bottom + 36, 1440 + 16 * 60 + 2],
  [L.wed.bottom, 2880],
  [L.late.bottom + 36, 2880 + 10 * 60 + 5],
];
function clockAt(wy) {
  if (wy <= CLOCK[0][0]) return CLOCK[0][1];
  for (let i = 0; i < CLOCK.length - 1; i++) {
    const [y0, m0] = CLOCK[i], [y1, m1] = CLOCK[i + 1];
    if (wy <= y1) return lerp(m0, m1, (wy - y0) / (y1 - y0));
  }
  return CLOCK[CLOCK.length - 1][1];
}
const START_MIN = CLOCK[0][1];
function fmtWait(min) {
  min = Math.max(0, Math.floor(min));
  const d = Math.floor(min / 1440), h = Math.floor((min % 1440) / 60), m = min % 60;
  if (d >= 2 && h === 0) return '2 DAYS';
  if (d >= 1) return `${d} DAY${d > 1 ? 'S' : ''} ${String(h).padStart(2, '0')} HRS`;
  if (h >= 1) return `${h} HR${h > 1 ? 'S' : ''} ${String(m).padStart(2, '0')} MIN`;
  return `${m} MIN`;
}
const q15 = t => Math.floor(t * 15) / 15;   // instruments update at 15 Hz

// ------------------------------------------------------------------ drawing
function drawPill(ctx, p, alpha = 1, sy = 1) {
  if (alpha <= 0 || sy <= 0.01) return;
  ctx.save();
  ctx.globalAlpha *= alpha;
  const cy = p.y + p.h / 2;
  ctx.translate(0, cy); ctx.scale(1, sy); ctx.translate(0, -cy);
  rr(ctx, p.x, p.y, p.w, p.h, 28); ctx.fillStyle = C.mist; ctx.fill();
  text(ctx, p.label, W / 2, p.y + 38, { fam: 'PlexMono', size: T.s12, colour: C.graphite, align: 'center', track: 3 });
  ctx.restore();
}

function bubbleShape(ctx, x, y, w, h, me) {
  rr(ctx, x, y, w, h, BUB.r);
  ctx.fillStyle = me ? C.ink : C.mist; ctx.fill();
}
function bubbleContent(ctx, b, x, y, w, h, alpha) {
  if (alpha <= 0) return;
  const me = b.side === 'me';
  ctx.save(); ctx.globalAlpha *= alpha;
  const fg = me ? C.paper : C.ink;
  b.lines.forEach((ln, i) => text(ctx, ln, x + BUB.padX, y + BUB.padT + (i + 1) * BUB.lead - 18, { size: BUB.size, colour: fg }));
  const sc2 = me ? C.silver : C.graphite;
  const sx = x + w - BUB.padX - (me ? 44 : 0);
  text(ctx, b.stamp, sx, y + h - 18, { fam: 'PlexMono', size: T.s11, colour: sc2, align: 'right' });
  if (me) ticks(ctx, sx + 10, y + h - 40, 24, C.silver, true, 2.6);
  ctx.restore();
}
function drawBubble(ctx, b, { alpha = 1, pop = 1, sy = 1, y = b.y, x = b.x, textAlpha = 1 } = {}) {
  if (alpha <= 0 || sy <= 0.01) return;
  const me = b.side === 'me';
  ctx.save();
  ctx.globalAlpha *= alpha * clamp(pop * 3);
  const sc = lerp(0.9, 1, E.outBack(clamp(pop), 1.6));
  const ox = me ? x + b.w : x, oy = y + b.h;
  ctx.translate(ox, oy); ctx.scale(sc, sc * sy); ctx.translate(-ox, -oy);
  bubbleShape(ctx, x, y, b.w, b.h, me);
  bubbleContent(ctx, b, x, y, b.w, b.h, textAlpha);
  ctx.restore();
}
// Morph between two bubbles on the same side: size lerps, text crossfades.
function drawMorph(ctx, a, b, m, y) {
  const w = lerp(a.w, b.w, m), h = lerp(a.h, b.h, m);
  bubbleShape(ctx, a.x, y, w, h, a.side === 'me');
  bubbleContent(ctx, a, a.x, y, w, h, 1 - seg(m, 0, 0.4));
  bubbleContent(ctx, b, a.x, y, w, h, seg(m, 0.6, 1));
}

function header(ctx, t) {
  ctx.fillStyle = C.paper; ctx.fillRect(0, 0, W, 344);
  ctx.fillStyle = C.silver; ctx.fillRect(0, 342, W, 2);
  // back chevron
  ctx.save(); ctx.strokeStyle = C.ink; ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.beginPath(); ctx.moveTo(86, 238); ctx.lineTo(64, 264); ctx.lineTo(86, 290); ctx.stroke(); ctx.restore();
  // avatar
  ctx.beginPath(); ctx.arc(172, 264, 46, 0, Math.PI * 2); ctx.fillStyle = C.mist; ctx.fill();
  text(ctx, 'YB', 172, 278, { fam: 'ArchivoMedium', size: T.s15, colour: C.ink, align: 'center' });
  text(ctx, 'Your Business', 240, 254, { fam: 'ArchivoMedium', size: T.s17 });
  let status = 'online';
  if (t >= TL.lastSeen && t < TL.collapse1) status = 'last seen today at 09:15';
  if (t >= POP.tue && t < TL.collapse1) status = 'last seen Monday at 09:15';
  if (t >= POP.late) status = 'online';
  text(ctx, status, 240, 300, { fam: 'PlexMono', size: T.s12, colour: C.graphite });
}

function inputBar(ctx, alpha) {
  if (alpha <= 0) return;
  ctx.save(); ctx.globalAlpha *= alpha;
  ctx.fillStyle = C.paper; ctx.fillRect(0, 1376, W, 140);
  rr(ctx, M, 1398, W - 2 * M - 110, 88, 44); ctx.fillStyle = C.mist; ctx.fill();
  text(ctx, 'Message', M + 40, 1455, { size: T.s15, colour: C.graphite });
  ctx.beginPath(); ctx.arc(W - M - 44, 1442, 44, 0, Math.PI * 2); ctx.fillStyle = C.ink; ctx.fill();
  // send arrow
  ctx.strokeStyle = C.paper; ctx.lineWidth = 4.5; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.beginPath(); ctx.moveTo(W - M - 44, 1462); ctx.lineTo(W - M - 44, 1422); ctx.moveTo(W - M - 60, 1438); ctx.lineTo(W - M - 44, 1422); ctx.lineTo(W - M - 28, 1438); ctx.stroke();
  ctx.restore();
}

// Dimension line (FM's annotation layer): graphite, end ticks.
function dimLine(ctx, x, y0, y1, lw) {
  if (y1 - y0 < 2) return;
  ctx.save(); ctx.strokeStyle = C.graphite; ctx.lineWidth = lw; ctx.lineCap = 'butt';
  ctx.beginPath(); ctx.moveTo(x, y0); ctx.lineTo(x, y1);
  ctx.moveTo(x - 12 * lw / 3, y0); ctx.lineTo(x + 12 * lw / 3, y0);
  ctx.moveTo(x - 12 * lw / 3, y1); ctx.lineTo(x + 12 * lw / 3, y1);
  ctx.stroke(); ctx.restore();
}

// ------------------------------------------------------------------ view
// Returns the world->screen transform at time t.
const ZOOM = (() => {
  const top = L.monday.y - 20, bot = L.late.bottom + 30;
  const s = (1440 - 420) / (bot - top);
  return { s, wy: top, sy: 420, cx: 620 };
})();
// After the fix the conversation is compact; this is where we land.
function compactLayout(g) {
  // g: 1 = original gap, 0 = closed
  const lateY = gapTop + MIN_GAP + (gapBot - gapTop - MIN_GAP) * g;
  return { lateY };
}
const FINAL_CAM = (() => {
  const lateY = compactLayout(0).lateY;
  const bookBottom = lateY + L.fix.h + 30 + L.book.h;
  return bookBottom + 36 - NOW;
})();

function view(t) {
  const scrollCam = camY(t);
  const pOut = E.inOutCubic(seg(t, TL.zoomOut0, TL.zoomOut1));
  const pIn = E.inOutCubic(seg(t, TL.zoomIn0, TL.zoomIn1));
  // scroll view: s=1, world y camY at screen 0
  const A = { s: 1, wy: scrollCam, sy: 0, cx: 540 };
  // closed-gap diagnostic view keeps the same scale but the strip is shorter
  const Z = ZOOM;
  const B = { s: 1, wy: FINAL_CAM, sy: 0, cx: 540 };
  let v;
  if (t < TL.zoomIn0) v = mixView(A, Z, pOut);
  else v = mixView(Z, B, pIn);
  return v;
}
function mixView(a, b, p) {
  // interpolate scale logarithmically and keep the motion of a screen anchor smooth
  const s = Math.exp(lerp(Math.log(a.s), Math.log(b.s), p));
  // anchor: screen centre y maps between the two views
  const ca = a.wy + (960 - a.sy) / a.s, cb = b.wy + (960 - b.sy) / b.s;
  const wc = lerp(ca, cb, p);
  const cx = lerp(a.cx, b.cx, p);
  return { s, wy: wc - 960 / s, sy: 0, cx };
}

// Gap factor: 1 = two days of space, 0 = closed. The fold starts slowly,
// accelerates, and latches with a small settle (never reopens past 0.03).
function gapFactor(t) {
  if (t < TL.collapse0) return 1;
  const u = seg(t, TL.collapse0, TL.collapse1);
  let G = 1 - E.inOutQuart(u);
  if (t > TL.collapse1) {
    const v = seg(t, TL.collapse1, TL.collapse1 + 0.3);
    G = -0.012 * Math.sin(Math.PI * v) * (1 - v);
  }
  return G;
}

// ------------------------------------------------------------------ frame
function draw(ctx, t) {
  ctx.fillStyle = C.paper; ctx.fillRect(0, 0, W, H);

  if (t >= TL.expand1) { drawEndCard(ctx, t - TL.expand1, ['Don’t buy more leads.', 'Answer the ones', 'you’ve got.']); return; }

  const v = view(t);
  const G = gapFactor(t);
  const lateY = compactLayout(G).lateY;
  const ratio = (lateY - gapTop) / (gapBot - gapTop);
  const mapY = y => (y <= gapTop ? y : gapTop + (y - gapTop) * ratio);
  const fadeGap = 1 - seg(t, TL.collapse0, TL.collapse0 + 0.45);

  ctx.save();
  ctx.setTransform(v.s, 0, 0, v.s, v.cx - 540 * v.s, v.sy - v.wy * v.s);

  // Monday + enquiry (settle on the first frames: rises 22 px)
  drawPill(ctx, L.monday);
  const settle = E.outCubic(seg(t, 0, 0.35));
  drawBubble(ctx, L.enq, { y: L.enq.y + (1 - settle) * 22 });
  const rA = E.outCubic(seg(t, TL.readIn, TL.readIn + 0.25));
  text(ctx, 'Read 09:14', W - M, L.read.y, { fam: 'PlexMono', size: T.s12, colour: C.graphite, align: 'right', alpha: rA });

  // the silence
  const popP = id => E.outCubic(seg(t, POP[id], POP[id] + 0.22));
  for (const id of ['hello', 'tue', 'found', 'wed']) {
    const el = L[id];
    if (t < POP[id]) continue;
    const sy = t < TL.collapse0 ? 1 : Math.max(0.02, ratio);
    const y = mapY(el.y);
    if (el.kind === 'pill') drawPill(ctx, { ...el, y }, popP(id) * fadeGap, sy);
    else drawBubble(ctx, el, { y, pop: popP(id), alpha: fadeGap, sy });
  }

  // the late reply, morphing into the on-time reply once the gap is closed
  if (t >= POP.late) {
    const m = E.inOutCubic(seg(t, TL.collapse0 + 0.35, TL.collapse1 + 0.05));
    if (m <= 0) drawBubble(ctx, L.late, { y: lateY, pop: popP('late') });
    else drawMorph(ctx, L.late, L.fix, m, lateY);
  }

  // booked
  const fixH = L.fix.h;
  const bookY = lateY + fixH + 30;
  if (t >= TL.booked) {
    const p = E.outCubic(seg(t, TL.booked, TL.booked + 0.22));
    const b = { ...L.book, y: bookY };
    if (t < TL.expand0) drawBubble(ctx, b, { y: bookY, pop: p });
    else {
      // the booking grows into the end card (drawn in screen space below)
    }
  }

  // FM dimension line: from the enquiry to the now line / the reply
  const nowWorld = camY(t) + NOW - 36;
  const dimEnd = t < POP.late ? Math.min(nowWorld, gapBot) : lateY;
  const dimA = seg(t, TL.scroll0 + 0.15, TL.scroll0 + 0.5) * (1 - seg(t, TL.zoomIn0 + 0.2, TL.zoomIn1));
  if (dimA > 0 && t >= TL.scroll0) {
    ctx.save(); ctx.globalAlpha *= dimA;
    dimLine(ctx, 30, L.enq.bottom, Math.max(L.enq.bottom, dimEnd), 3 / v.s);
    ctx.restore();
  }
  ctx.restore();

  // ---------------- screen-space layers
  header(ctx, t);
  inputBar(ctx, 1 - seg(t, TL.zoomOut0, TL.zoomOut0 + 0.35) + seg(t, TL.zoomIn1 - 0.3, TL.zoomIn1));

  // wait counter riding the dimension line during the scroll
  const wait = t < POP.late ? clockAt(camY(q15(t)) + NOW - 36) - START_MIN : 2880 + 51;
  const cA = seg(t, TL.scroll0 + 0.2, TL.scroll0 + 0.5) * (1 - seg(t, TL.zoomOut0, TL.zoomOut0 + 0.3));
  if (cA > 0) {
    // label sits at the middle of the visible part of the line
    const topS = Math.max(360, (L.enq.bottom - v.wy) * v.s);
    const botS = Math.min(NOW, (dimEnd - v.wy) * v.s);
    const midS = clamp((topS + botS) / 2, 560, 1180);
    text(ctx, t < POP.late ? 'NO REPLY' : 'REPLIED AFTER', 60, midS - 28, { fam: 'PlexMono', size: T.s12, colour: C.graphite, track: 2, alpha: cA });
    text(ctx, fmtWait(wait), 60, midS + 26, { fam: 'PlexMonoMedium', size: T.s17, colour: C.ink, alpha: cA });
  }

  // diagnostic spec block (FM's view)
  const sA = E.outCubic(seg(t, TL.specIn, TL.specIn + 0.4)) * (1 - seg(t, TL.zoomIn0 - 0.05, TL.zoomIn0 + 0.22));
  if (sA > 0) {
    const fmP = E.outCubic(seg(t, TL.fmIn, TL.fmIn + 0.35));
    drawLogo(ctx, 'fm-monogram', 96, 610 + (1 - fmP) * 14, 108, C.ink, fmP * sA);
    const lx = 96;
    text(ctx, 'OWNER', lx, 862, { fam: 'PlexMono', size: T.s12, colour: C.graphite, track: 2, alpha: sA });
    // NOBODY -> struck -> THANDI
    const sk = E.outCubic(seg(t, TL.strike, TL.strike + 0.2));
    const nobodyA = 1 - seg(t, TL.newOwner, TL.newOwner + 0.12);
    text(ctx, 'NOBODY', lx, 938, { fam: 'PlexMonoMedium', size: T.s27, colour: C.ink, alpha: sA * nobodyA });
    if (sk > 0 && nobodyA > 0) {
      ctx.save(); ctx.globalAlpha *= sA * nobodyA; ctx.fillStyle = C.ink;
      ctx.fillRect(lx - 6, 914, (measure(ctx, 'NOBODY', 'PlexMonoMedium', T.s27) + 12) * sk, 6); ctx.restore();
    }
    const nm = 'THANDI';
    const nChars = Math.floor(seg(t, TL.newOwner + 0.06, TL.newOwner + 0.36) * nm.length + 0.001);
    if (nChars > 0) text(ctx, nm.slice(0, nChars), lx, 938, { fam: 'PlexMonoMedium', size: T.s27, colour: C.ink, alpha: sA });

    text(ctx, 'REPLY TIME', lx, 1066, { fam: 'PlexMono', size: T.s12, colour: C.graphite, track: 2, alpha: sA });
    // counts down with the gap
    const tq = q15(t);
    const Gq = clamp(gapFactor(tq));
    const mins = Gq >= 0.999 ? 2931 : Math.max(5, Math.round(5 + (2931 - 5) * Math.pow(clamp(Gq), 1.6)));
    const short = mins >= 2880 ? '2 DAYS' : mins >= 120 ? `${Math.round(mins / 60)} HRS` : mins > 5 ? `${mins} MIN` : '5 MIN';
    text(ctx, short, lx, 1142, { fam: 'PlexMonoMedium', size: T.s27, colour: C.ink, alpha: sA });
  }

  // after the fix: small annotation beside the enquiry
  const aA = E.outCubic(seg(t, TL.zoomIn1 - 0.2, TL.zoomIn1 + 0.3)) * (1 - seg(t, TL.expand0, TL.expand0 + 0.2));
  if (aA > 0) {
    const ey = (L.enq.y - v.wy) * v.s;
    text(ctx, 'REPLY IN', M, ey + 64, { fam: 'PlexMono', size: T.s12, colour: C.graphite, track: 2, alpha: aA });
    text(ctx, '5 MIN', M, ey + 112, { fam: 'PlexMonoMedium', size: T.s15, colour: C.ink, alpha: aA });
  }

  // expansion of the booking bubble into the ink end card
  if (t >= TL.expand0) {
    const p = E.inOutCubic(seg(t, TL.expand0, TL.expand1));
    const b = L.book;
    const bx = W - M - b.w, by = (bookY - v.wy) * v.s;
    const x0 = lerp(bx, 0, p), y0 = lerp(by, 0, p), x1 = lerp(bx + b.w, W, p), y1 = lerp(by + b.h, H, p);
    rr(ctx, x0, y0, x1 - x0, y1 - y0, BUB.r * (1 - p)); ctx.fillStyle = C.ink; ctx.fill();
    const ta = 1 - seg(p, 0, 0.25);
    if (ta > 0) bubbleContent(ctx, b, bx, by, b.w, b.h, ta);
  }
}

// Motion blur only where things move fast: enough samples that successive
// copies sit no more than ~2 px apart across a 180-degree shutter.
function subframes(t) {
  let n = 1;
  if (t > TL.scroll0 && t < TL.scroll1 + 0.05) {
    const v = Math.abs(camY(t + 0.005) - camY(t - 0.005)) / 0.01;   // px/s
    n = Math.ceil(v / 60 / 2);
  }
  if (t > TL.zoomOut0 && t < TL.zoomOut1) n = Math.max(n, 8);
  if (t > TL.collapse0 && t < TL.zoomIn1) n = Math.max(n, 10);
  if (t > TL.expand0 && t < TL.expand1) n = Math.max(n, 10);
  return Math.max(1, Math.min(12, n));
}

// sound cues (seconds)
const CUES = {
  send: [0.02, TL.booked],
  read: [TL.readIn],
  sendSoft: [POP.hello, POP.found],
  pill: [POP.tue, POP.wed],
  receive: [POP.late],
  scroll: [TL.scroll0, TL.scroll1],
  zoomOut: [TL.zoomOut0, TL.zoomOut1],
  signature: [TL.fmIn, TL.expand1 + LOCKUP_LAND],
  strike: [TL.strike],
  type: [TL.newOwner + 0.06, TL.newOwner + 0.36],
  collapse: [TL.collapse0, TL.collapse1],
  zoomIn: [TL.zoomIn0, TL.zoomIn1],
  expand: [TL.expand0, TL.expand1],
  duration: TL.duration,
};
// scroll speed (px/s) sampled at 100 Hz, drives the clock ticks and air in the mix
CUES.scrollVel = [];
for (let t = 0; t < TL.duration; t += 0.01) CUES.scrollVel.push(+((camY(t + 0.005) - camY(t - 0.005)) / 0.01).toFixed(1));
// clock minutes along the scroll (for tick spacing: one tick per simulated 20 minutes)
CUES.clock = [];
for (let t = 0; t < TL.duration; t += 0.01) CUES.clock.push(+(clockAt(camY(t) + NOW - 36) - START_MIN).toFixed(2));

module.exports = { duration: TL.duration, draw, subframes, CUES, TL, POP };
