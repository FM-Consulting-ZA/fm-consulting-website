# contact sheet: python3 sheet.py out.png cols img1 img2 ...
import sys, os
from PIL import Image, ImageDraw, ImageFont
out, cols, files = sys.argv[1], int(sys.argv[2]), sys.argv[3:]
files = sorted(files, key=lambda f: float(os.path.basename(f).rsplit('_',1)[-1][:-4]))
ims = [Image.open(f).convert('RGB') for f in files]
w, h = ims[0].size
lab = 34
pad = 12
rows = (len(ims) + cols - 1) // cols
S = Image.new('RGB', (cols * (w + pad) + pad, rows * (h + lab + pad) + pad), (120, 124, 122))
d = ImageDraw.Draw(S)
try: f = ImageFont.truetype('assets/fonts/IBMPlexMono-500.ttf', 22)
except: f = None
for i, (im, fn) in enumerate(zip(ims, files)):
    r, c = divmod(i, cols)
    x, y = pad + c * (w + pad), pad + r * (h + lab + pad)
    S.paste(im, (x, y + lab))
    t = os.path.basename(fn).rsplit('_', 1)[-1].replace('.png', '')
    d.text((x + 4, y + 6), t + 's', fill=(255, 255, 255), font=f)
S.save(out)
print(out, S.size)
