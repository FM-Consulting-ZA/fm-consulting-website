// Covers, style frames and timed storyboards, all rendered from the film code.
// usage: node extras.js
'use strict';
const fs = require('fs');
const { createCanvas } = require('@napi-rs/canvas');
const X = require('./lib/engine');
const { C, T, W, H, text, wrap, drawLogo } = X;
const F1 = require('./film1_left_on_read.js');
const F2 = require('./film2_apply_to_buy.js');

fs.mkdirSync('final/covers', { recursive: true });
fs.mkdirSync('final/style_frames', { recursive: true });
fs.mkdirSync('final/storyboards', { recursive: true });

// ---------------------------------------------------------------- covers
// A cover is the film's most recognisable frame, dropped 120 px so it also
// survives the 4:5 profile-grid crop (y 285-1635).
function cover(film, t, file, dy = 120) {
  const { canvas, ctx } = X.makeCtx();
  ctx.fillStyle = C.paper; ctx.fillRect(0, 0, W, H);
  ctx.save(); ctx.translate(0, dy); film.draw(ctx, t); ctx.restore();
  ctx.fillStyle = C.paper; ctx.fillRect(0, 0, W, dy);
  fs.writeFileSync(file, canvas.toBuffer('image/png'));
  console.log(file);
}
cover(F1, 6.95, 'final/covers/FM_LeftOnRead_cover.png');
cover(F2, 6.25, 'final/covers/FM_ApplyToBuy_cover.png');

// ---------------------------------------------------------------- style frames
const SF = [
  [F1, 0.0, 'LeftOnRead_01_opening'], [F1, 6.95, 'LeftOnRead_02_still-keen'], [F1, 9.4, 'LeftOnRead_03_fm-steps-back'],
  [F1, 13.9, 'LeftOnRead_04_booked'], [F1, 17.6, 'LeftOnRead_05_endcard'],
  [F2, 0.2, 'ApplyToBuy_01_opening'], [F2, 6.25, 'ApplyToBuy_02_customer-left'], [F2, 7.75, 'ApplyToBuy_03_fm-edit'],
  [F2, 12.3, 'ApplyToBuy_04_sent'], [F2, 16.8, 'ApplyToBuy_05_endcard'],
];
for (const [f, t, n] of SF) { X.renderStill(f, t, `final/style_frames/FM_${n}.png`); console.log(n); }

// ---------------------------------------------------------------- storyboards
function storyboard(film, title, sub, panels, file) {
  const cols = 4, pw = 300, ph = 533, gx = 52, tx = 150;
  const rows = Math.ceil(panels.length / cols);
  const cw = 100 + cols * pw + (cols - 1) * gx + 100;
  const ch = 330 + rows * (ph + 400) + 60;
  const cv = createCanvas(cw, ch), ctx = cv.getContext('2d');
  ctx.fillStyle = C.paper; ctx.fillRect(0, 0, cw, ch);
  text(ctx, 'FM CONSULTING · BRAND FILM · TIMED STORYBOARD', 100, 112, { fam: 'PlexMono', size: 26, colour: C.graphite, track: 3 });
  text(ctx, title, 100, 200, { fam: 'ArchivoLight', size: 72, colour: C.ink });
  text(ctx, sub, 100, 256, { fam: 'ArchivoRegular', size: 30, colour: C.graphite });
  drawLogo(ctx, 'fm-monogram', cw - 100 - 80, 120, 80, C.ink);
  ctx.fillStyle = C.silver; ctx.fillRect(100, 290, cw - 200, 2);
  const { canvas: fc, ctx: fx } = X.makeCtx();
  panels.forEach((p, i) => {
    const c = i % cols, r = Math.floor(i / cols);
    const x = 100 + c * (pw + gx), y = 330 + r * (ph + 400);
    fx.save(); fx.setTransform(1, 0, 0, 1, 0, 0); film.draw(fx, p.t); fx.restore();
    ctx.drawImage(fc, x, y, pw, ph);
    ctx.strokeStyle = C.silver; ctx.lineWidth = 2; ctx.strokeRect(x, y, pw, ph);
    text(ctx, `${String(i + 1).padStart(2, '0')}  ${p.t.toFixed(1).padStart(4, '0')}s`, x, y + ph + 42, { fam: 'PlexMonoMedium', size: 24, colour: C.ink });
    let yy = y + ph + 82;
    for (const [lab, body, fam] of [['', p.act, 'ArchivoRegular'], ['ON SCREEN ', p.copy, 'ArchivoRegular'], ['SOUND ', p.snd, 'ArchivoRegular']]) {
      if (!body) continue;
      if (lab) { text(ctx, lab.trim(), x, yy, { fam: 'PlexMono', size: 17, colour: C.graphite, track: 2 }); yy += 26; }
      for (const ln of wrap(ctx, body, fam, 21, pw)) { text(ctx, ln, x, yy, { fam, size: 21, colour: lab ? C.graphite : C.ink }); yy += 28; }
      yy += 10;
    }
  });
  fs.writeFileSync(file, cv.toBuffer('image/png'));
  console.log(file);
}

storyboard(F1, 'Left on read', `“That is exactly the problem.”  ·  ${F1.duration.toFixed(1)} s  ·  1080 × 1920  ·  30 fps`, [
  { t: 0.0, act: 'Frame one: a customer’s chat with Your Business. The enquiry is already sent.', copy: 'Hi, can I get a quote? Need it done this week.', snd: 'Send swoosh.' },
  { t: 1.2, act: 'Read at 09:14. Status drops to “last seen”.', copy: 'Read 09:14', snd: 'Read tick.' },
  { t: 2.9, act: 'Scroll: empty space is waiting time. A dimension line measures it.', copy: 'NO REPLY 2 HRS 21 MIN · Hello?', snd: 'Clock ticks follow the scroll; low held tone.' },
  { t: 4.8, act: 'Day changes. The customer moves on.', copy: 'TUESDAY · All good, found someone else.', snd: 'Ticks, air.' },
  { t: 6.95, act: 'The business finally replies. Hold for the laugh.', copy: 'Hi! So sorry for the delay. Still keen? · REPLIED AFTER 2 DAYS', snd: 'Cheerful ding, then the tone cuts dead.' },
  { t: 9.4, act: 'FM steps back: the whole two days as one object, and the diagnosis.', copy: 'OWNER NOBODY · REPLY TIME 2 DAYS', snd: 'Air down; FM signature tock.' },
  { t: 10.2, act: 'FM gives the enquiry an owner.', copy: 'NOBODY becomes THANDI', snd: 'Pen strike, type.' },
  { t: 10.85, act: 'The two days fold shut. The late reply becomes an on-time one.', copy: 'REPLY TIME counts down to 5 MIN', snd: 'Rising zip, firm latch.' },
  { t: 12.6, act: 'Back in the chat: answered at 09:19.', copy: 'Hi! Yes, we can. Thursday at 10:00? · REPLY IN 5 MIN', snd: 'Warm resolved chord.' },
  { t: 13.9, act: 'Booked.', copy: 'Perfect, book me in.', snd: 'Send swoosh.' },
  { t: 14.5, act: 'The booking grows into the ink end card.', copy: '', snd: 'Low swell.' },
  { t: 17.5, act: 'End card: line, reversed lockup, URL.', copy: 'Don’t buy more leads. Answer the ones you’ve got.', snd: 'FM signature tock as the lockup lands.' },
], 'final/storyboards/FM_LeftOnRead_storyboard.png');

storyboard(F2, 'Apply to buy', `“That is a better way.”  ·  ${F2.duration.toFixed(1)} s  ·  1080 × 1920  ·  30 fps`, [
  { t: 0.2, act: 'A quote page. A thumb goes for the only button.', copy: 'yourbusiness.co.za/quote · Need a quote? · Get a quote', snd: 'Room tone.' },
  { t: 0.5, act: 'Tap. A field appears and shoves the button down.', copy: 'Name', snd: 'Tap, first block lands.' },
  { t: 2.4, act: 'Every new question pushes the button further away. The thumb chases.', copy: 'Surname · Email · Confirm email · Phone …', snd: 'Blocks land a semitone higher each time; rhythm tightens.' },
  { t: 4.6, act: 'The button is gone off the bottom of the screen.', copy: 'QUESTIONS 12', snd: 'Tension bed.' },
  { t: 5.4, act: 'Pause. Then the last straw lands on top.', copy: 'Fax', snd: 'Heavy low thud and rattle.' },
  { t: 6.25, act: 'The thumb gives up and leaves.', copy: 'QUESTIONS 13 · CUSTOMER LEFT', snd: 'Swish away, then silence.' },
  { t: 7.6, act: 'FM signs the page and cuts the form. One question is rewritten.', copy: '“How did you hear about us?” becomes “What do you need?”', snd: 'FM tock; eleven quick pen strikes.' },
  { t: 8.3, act: 'The cut questions fall away; the three that matter stay.', copy: 'QUESTIONS 3', snd: 'Downward air, soft landings off-screen.' },
  { t: 9.1, act: 'The button springs back into reach.', copy: 'Name · Phone · What do you need? · ASK THE REST ON THE CALL', snd: 'Rising pluck.' },
  { t: 10.6, act: 'The thumb returns and fills three fields.', copy: 'Lebo · 082 ••• •••• · A quote by Friday, please.', snd: 'Key ticks.' },
  { t: 12.3, act: 'Sent.', copy: 'Thanks, Lebo. We’ll call you in 10 minutes.', snd: 'Bright two-note chime.' },
  { t: 16.8, act: 'The button grows into the end card.', copy: 'Stop making customers apply to buy from you.', snd: 'Low swell; FM signature tock.' },
], 'final/storyboards/FM_ApplyToBuy_storyboard.png');
