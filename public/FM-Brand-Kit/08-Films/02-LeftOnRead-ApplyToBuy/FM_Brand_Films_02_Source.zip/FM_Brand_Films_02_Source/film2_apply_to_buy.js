// FILM 2 — APPLY TO BUY   ("That is a better way.")
// One mechanism: every question the form adds shoves the button further out
// of reach. The camera never moves; objects do. FM cuts the form to three
// questions and the button springs back under the customer's thumb.
'use strict';
const X = require('./lib/engine');
const { C, T, W, H, E, seg, lerp, clamp, rr, text, measure, drawLogo } = X;
const { drawEndCard, LOCKUP_LAND } = require('./lib/endcard');

// ------------------------------------------------------------------ fields
const FIELDS = [
  'Name', 'Surname', 'Email', 'Confirm email', 'Phone', 'Company', 'Job title',
  'Company size', 'Monthly budget', 'Province', 'How did you hear about us?', 'ID number', 'Fax',
];
const KEEP = { 0: 'Name', 4: 'Phone', 10: 'What do you need?' };   // index -> label after the edit
const REWRITE = 10;

// accelerating rhythm, then a pause, then the last straw
const INS = [];
{
  let t = 0.78;
  const gaps = [0.52, 0.48, 0.43, 0.39, 0.35, 0.31, 0.28, 0.26, 0.24, 0.22, 0.21];
  INS.push(t);
  for (const g of gaps) { t += g; INS.push(t); }
  INS.push(t + 0.72);          // Fax
}

const TL = {
  tap: 0.42,
  fax: INS[12],
  leave0: INS[12] + 0.55, leave1: INS[12] + 0.95,
  left: INS[12] + 0.85,
  fmIn: INS[12] + 1.20,
  strike0: INS[12] + 1.45,
  fall0: 0, fall1: 0,
  springUp: 0,
  back: 0,
  duration: 0,
};
TL.strikeGap = 0.105;
// strike order: top to bottom as they sit on screen (newest first), skipping keeps
const ORDER = [12, 11, 10, 9, 8, 7, 6, 5, 3, 2, 1];
TL.strikeEnd = TL.strike0 + ORDER.length * TL.strikeGap + 0.12;
TL.rewrite0 = TL.strike0 + ORDER.indexOf(REWRITE) * TL.strikeGap + 0.2;
TL.fall0 = TL.strikeEnd + 0.12;
TL.fall1 = TL.fall0 + 0.75;
TL.reorder0 = TL.fall0 + 0.10; TL.reorder1 = TL.fall0 + 0.62;
TL.springUp = TL.fall0 + 0.45;
TL.later = TL.fall0 + 0.75;
TL.back = TL.springUp + 0.75;          // thumb returns
TL.type0 = TL.back + 0.35;
TL.tap2 = TL.type0 + 1.45;
TL.sent = TL.tap2 + 0.08;
TL.confirm = TL.tap2 + 0.28;
TL.expand0 = TL.confirm + 1.35;
TL.expand1 = TL.expand0 + 0.68;
TL.duration = TL.expand1 + 4.0;

// ------------------------------------------------------------------ layout
const M = 80;
const TOP = 468;                 // first field slot
const FH = 104, PITCH = 122;     // field height, pitch
const BTN_H = 128;
const FW = W - 2 * M;

// critically-damped-ish settle with a little overshoot (0.18 s)
function kick(tau, dur = 0.2, back = 1.3) {
  if (tau <= 0) return 0;
  const s = clamp(tau / dur);
  return E.outBack(s, back);
}

// number of fields inserted by time t, and the stack offset for a field
function stackShift(t, i) {
  // every field inserted after i pushes it down one pitch
  let s = 0;
  for (let j = i + 1; j < FIELDS.length; j++) s += PITCH * kick(t - INS[j], j === 12 ? 0.3 : 0.2, j === 12 ? 2.2 : 1.3);
  return s;
}
function buttonShiftBefore(t) {
  let s = 0;
  for (let j = 0; j < FIELDS.length; j++) s += PITCH * kick(t - INS[j], j === 12 ? 0.3 : 0.2, j === 12 ? 2.2 : 1.3);
  return s;
}

// ---- after the edit: kept fields reorder into three slots
const KEPT_ORDER = [0, 4, 10];
function keptSlot(i) { return TOP + KEPT_ORDER.indexOf(i) * PITCH; }
function fieldY(t, i) {
  const base = TOP + stackShift(t, i);
  if (t < TL.reorder0 || !(i in KEEP)) return base;
  const p = E.inOutCubic(seg(t, TL.reorder0 + KEPT_ORDER.indexOf(i) * 0.04, TL.reorder1 + KEPT_ORDER.indexOf(i) * 0.04));
  return lerp(base, keptSlot(i), p);
}
const BTN_FINAL = TOP + 3 * PITCH + 22;
function buttonY(t) {
  const before = TOP + 22 + buttonShiftBefore(t);
  if (t < TL.springUp) return before;
  const p = clamp(X.spring(seg(t, TL.springUp, TL.springUp + 0.9) * 0.9, 1.6, 6.5));
  return lerp(Math.min(before, H + 80), BTN_FINAL, p);
}

// fallen fields: deterministic pseudo-random spin and drift
function rnd(i, k) { const x = Math.sin(i * 127.1 + k * 311.7) * 43758.5453; return x - Math.floor(x); }

// ------------------------------------------------------------------ thumb path
// Simulated once at 600 Hz (a lagging follower chasing the button), then sampled.
const THUMB = (() => {
  const dt = 1 / 600, out = [];
  let x = 830, y = 1180, vx = 0, vy = 0;
  const w = 13, z = 0.9;
  for (let t = 0; t <= TL.duration; t += dt) {
    let tx, ty;
    const bcY = buttonY(t) + BTN_H / 2;
    if (t < TL.tap) {           // approach and tap
      const p = E.inOutCubic(seg(t, 0, TL.tap - 0.04));
      tx = lerp(830, 770, p); ty = lerp(1180, TOP + 22 + BTN_H / 2, p);
      x = tx; y = ty; vx = vy = 0;
    } else if (t < TL.leave0) { // chase, but never below the screen edge
      tx = 770; ty = Math.min(bcY - 8, 1760);
      const ax = w * w * (tx - x) - 2 * z * w * vx, ay = w * w * (ty - y) - 2 * z * w * vy;
      vx += ax * dt; vy += ay * dt; x += vx * dt; y += vy * dt;
    } else {
      x += 0; y += 0;
    }
    out.push([x, y]);
  }
  return out;
})();
function thumbAt(t) {
  const i = clamp(Math.floor(t * 600), 0, THUMB.length - 1);
  return THUMB[i];
}
// attempted taps while chasing (near misses)
const LUNGES = [INS[2] + 0.12, INS[5] + 0.1, INS[8] + 0.06];

// ------------------------------------------------------------------ drawing
function urlBar(ctx) {
  rr(ctx, M, 176, FW, 84, 42); ctx.fillStyle = C.mist; ctx.fill();
  // padlock
  ctx.save(); ctx.strokeStyle = C.graphite; ctx.lineWidth = 3.2; ctx.fillStyle = C.graphite;
  rr(ctx, M + 40, 216, 22, 18, 3); ctx.fill();
  ctx.beginPath(); ctx.arc(M + 51, 216, 7.5, Math.PI, 0); ctx.stroke(); ctx.restore();
  text(ctx, 'yourbusiness.co.za/quote', M + 80, 230, { fam: 'PlexMono', size: T.s13, colour: C.graphite });
}

function field(ctx, i, y, { label, strike = 0, labelAlpha = 1, strong = false, value = '', rewrite = null, alpha = 1 }) {
  ctx.save(); ctx.globalAlpha *= alpha;
  rr(ctx, M, y, FW, FH, 16);
  ctx.fillStyle = C.paper; ctx.fill();
  ctx.lineWidth = strong ? 3.5 : 3; ctx.strokeStyle = strong ? C.graphite : C.silver; ctx.stroke();
  const ty = y + FH / 2 + 15;
  if (value) text(ctx, value, M + 36, ty, { size: T.s17, colour: C.ink });
  else {
    text(ctx, label, M + 36, ty, { size: T.s17, colour: C.graphite, alpha: labelAlpha });
    if (rewrite) {
      const n = Math.floor(rewrite.p * rewrite.to.length + 0.001);
      if (n > 0) text(ctx, rewrite.to.slice(0, n), M + 36, ty, { fam: 'ArchivoMedium', size: T.s17, colour: C.ink });
    }
  }
  if (strike > 0) {
    ctx.fillStyle = C.ink;
    const x0 = M - 18, x1 = W - M + 18;
    ctx.fillRect(x0, y + FH / 2 - 4, (x1 - x0) * strike, 8);
  }
  ctx.restore();
}

function button(ctx, y, { label = 'Get a quote', press = 0, sentP = 0 } = {}) {
  const sc = 1 - 0.035 * press;
  ctx.save();
  ctx.translate(W / 2, y + BTN_H / 2); ctx.scale(sc, sc); ctx.translate(-W / 2, -(y + BTN_H / 2));
  rr(ctx, M, y, FW, BTN_H, 22); ctx.fillStyle = C.ink; ctx.fill();
  if (sentP <= 0) text(ctx, label, W / 2, y + BTN_H / 2 + 18, { fam: 'ArchivoMedium', size: T.s21, colour: C.paper, align: 'center' });
  else {
    const a = E.outCubic(sentP);
    text(ctx, 'Sent', W / 2 + 26, y + BTN_H / 2 + 18, { fam: 'ArchivoMedium', size: T.s21, colour: C.paper, align: 'center', alpha: a });
    // check mark drawn on
    ctx.strokeStyle = C.paper; ctx.lineWidth = 7; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    const cx = W / 2 - 64, cy = y + BTN_H / 2;
    const pts = [[cx - 20, cy + 1], [cx - 6, cy + 15], [cx + 20, cy - 14]];
    const L1 = Math.hypot(14, 14), L2 = Math.hypot(26, 29), tot = L1 + L2, d = tot * E.outCubic(seg(sentP, 0, 0.8));
    ctx.beginPath(); ctx.moveTo(...pts[0]);
    if (d <= L1) ctx.lineTo(lerp(pts[0][0], pts[1][0], d / L1), lerp(pts[0][1], pts[1][1], d / L1));
    else { ctx.lineTo(...pts[1]); ctx.lineTo(lerp(pts[1][0], pts[2][0], (d - L1) / L2), lerp(pts[1][1], pts[2][1], (d - L1) / L2)); }
    ctx.stroke();
  }
  ctx.restore();
}

function thumb(ctx, x, y, { scale = 1, alpha = 1, ripple = 0 } = {}) {
  if (alpha <= 0) return;
  ctx.save(); ctx.globalAlpha *= alpha;
  if (ripple > 0 && ripple < 1) {
    ctx.beginPath(); ctx.arc(x, y, 48 + 90 * E.outCubic(ripple), 0, Math.PI * 2);
    ctx.strokeStyle = C.graphite; ctx.globalAlpha *= (1 - ripple) * 0.7; ctx.lineWidth = 3; ctx.stroke();
    ctx.globalAlpha = alpha;
  }
  ctx.beginPath(); ctx.arc(x, y, 46 * scale, 0, Math.PI * 2);
  ctx.fillStyle = C.silver; ctx.globalAlpha *= 0.55; ctx.fill();
  ctx.globalAlpha = alpha;
  ctx.lineWidth = 4; ctx.strokeStyle = C.graphite; ctx.stroke();
  ctx.restore();
}

function counter(ctx, n, alpha = 1, extra = null) {
  text(ctx, 'QUESTIONS', W - M, 330, { fam: 'PlexMono', size: T.s12, colour: C.graphite, align: 'right', track: 2, alpha });
  text(ctx, String(n), W - M, 408, { fam: 'PlexMonoMedium', size: T.s27, colour: C.ink, align: 'right', alpha });
}

// ------------------------------------------------------------------ frame
function draw(ctx, t) {
  ctx.fillStyle = C.paper; ctx.fillRect(0, 0, W, H);
  if (t >= TL.expand1) { drawEndCard(ctx, t - TL.expand1, ['Stop making customers', 'apply to buy', 'from you.']); return; }

  urlBar(ctx);

  // heading hands over to FM's monogram during the edit, then comes back
  const fmA = E.outCubic(seg(t, TL.fmIn, TL.fmIn + 0.3)) * (1 - E.outCubic(seg(t, TL.back - 0.3, TL.back - 0.1)));
  const hA = (1 - seg(t, TL.fmIn - 0.15, TL.fmIn)) + seg(t, TL.back - 0.05, TL.back + 0.2);
  text(ctx, 'Need a quote?', M, 404, { fam: 'ArchivoLight', size: T.s34, colour: C.ink, alpha: hA });
  if (fmA > 0) drawLogo(ctx, 'fm-monogram', M, 300 + (1 - E.outCubic(seg(t, TL.fmIn, TL.fmIn + 0.3))) * 12, 112, C.ink, fmA);

  // counter
  let n = 0; for (const ti of INS) if (t >= ti) n++;
  if (t >= TL.fall0) n = Math.round(lerp(13, 3, E.inOutCubic(seg(Math.floor(t * 15) / 15, TL.fall0 + 0.05, TL.fall0 + 0.6))));
  counter(ctx, n, t < INS[0] ? 0.0 + seg(t, 0.5, INS[0]) : 1);

  // fields: struck ones first so the kept three always sit on top as the rest fall
  const drawOrder = [...Array(FIELDS.length).keys()].sort((a, b) => ((a in KEEP) - (b in KEEP)) || (a - b));
  for (const i of drawOrder) {
    if (t < INS[i]) continue;
    const pIn = E.outCubic(seg(t, INS[i], INS[i] + 0.16));
    let y = fieldY(t, i) - (1 - pIn) * (i === 12 ? 110 : 46);
    const kept = i in KEEP;
    const si = ORDER.indexOf(i);
    const strike = si < 0 ? 0 : E.outCubic(seg(t, TL.strike0 + si * TL.strikeGap, TL.strike0 + si * TL.strikeGap + 0.1));
    const opt = { label: FIELDS[i], alpha: pIn, strike };
    if (i === REWRITE) {
      // struck, then rewritten; the strike fades once the new question is in
      const rp = seg(t, TL.rewrite0 + 0.14, TL.rewrite0 + 0.5);
      opt.labelAlpha = 1 - seg(t, TL.rewrite0, TL.rewrite0 + 0.12);
      opt.rewrite = { to: KEEP[i], p: rp };
      opt.strike = strike * (1 - seg(t, TL.rewrite0, TL.rewrite0 + 0.12));
      if (rp >= 1) { opt.label = KEEP[i]; opt.labelAlpha = 0; }
    }
    if (kept && t >= TL.strikeEnd) opt.strong = true;
    // values typed after the edit
    const VAL = { 0: 'Lebo', 4: '082 ••• ••••', 10: 'A quote by Friday, please.' };
    if (kept && t >= TL.type0) {
      const k = KEPT_ORDER.indexOf(i);
      const a0 = TL.type0 + [0, 0.38, 0.72][k], a1 = a0 + [0.22, 0.26, 0.55][k];
      const nC = Math.floor(seg(t, a0, a1) * VAL[i].length + 0.001);
      if (nC > 0) { opt.value = VAL[i].slice(0, nC); }
    }
    // falling
    if (!kept && t >= TL.fall0) {
      const d = 0.02 * (ORDER.indexOf(i));
      const tau = Math.max(0, t - TL.fall0 - d);
      const g = 5200, v0 = -260 - 140 * rnd(i, 1);
      const dy = v0 * tau + 0.5 * g * tau * tau;
      const rot = (rnd(i, 2) - 0.5) * 0.22 * tau * 3;
      const dx = (rnd(i, 3) - 0.5) * 120 * tau;
      if (y + dy > H + 200) continue;
      ctx.save();
      ctx.translate(W / 2 + dx, y + dy + FH / 2); ctx.rotate(rot); ctx.translate(-W / 2, -(y + FH / 2));
      field(ctx, i, y, opt);
      ctx.restore();
      continue;
    }
    field(ctx, i, y, opt);
  }

  // button
  const by = buttonY(t);
  let press = 0;
  press = Math.max(press, 1 - Math.abs(t - TL.tap) / 0.09);
  press = Math.max(press, 1 - Math.abs(t - TL.tap2) / 0.09);
  const sentP = seg(t, TL.sent, TL.sent + 0.35);
  if (by < H + 10) button(ctx, by, { press: clamp(press), sentP });

  // ask later note, where the questions fell
  const lA = E.outCubic(seg(t, TL.later, TL.later + 0.35)) * (1 - seg(t, TL.expand0, TL.expand0 + 0.15));
  if (lA > 0) {
    text(ctx, 'ASK THE REST ON THE CALL', M, BTN_FINAL + BTN_H + 250, { fam: 'PlexMono', size: T.s13, colour: C.graphite, track: 2, alpha: lA });
    ctx.save(); ctx.globalAlpha *= lA; ctx.fillStyle = C.silver; ctx.fillRect(M, BTN_FINAL + BTN_H + 188, FW, 2); ctx.restore();
  }
  // confirmation
  const cA = E.outCubic(seg(t, TL.confirm, TL.confirm + 0.3)) * (1 - seg(t, TL.expand0, TL.expand0 + 0.15));
  if (cA > 0) text(ctx, 'Thanks, Lebo. We’ll call you in 10 minutes.', M, BTN_FINAL + BTN_H + 104 + (1 - cA) * 12, { size: T.s17, colour: C.ink, alpha: cA });

  // "customer left"
  const gA = E.outCubic(seg(t, TL.left, TL.left + 0.25)) * (1 - seg(t, TL.fmIn + 0.2, TL.fmIn + 0.5));
  if (gA > 0) text(ctx, 'CUSTOMER LEFT', W - M, 454, { fam: 'PlexMonoMedium', size: T.s12, colour: C.ink, align: 'right', track: 2, alpha: gA });

  // thumb
  let [tx, ty] = thumbAt(t);
  let tA = 1, tS = 1, rip = 0;
  if (t >= TL.tap - 0.05 && t < TL.tap + 0.45) rip = seg(t, TL.tap, TL.tap + 0.45);
  for (const l of LUNGES) { const k = 1 - Math.abs(t - l) / 0.1; if (k > 0) tS = Math.min(tS, 1 - 0.2 * k); }
  if (Math.abs(t - TL.tap) < 0.1) tS = Math.min(tS, 1 - 0.2 * (1 - Math.abs(t - TL.tap) / 0.1));
  if (t >= TL.leave0) {
    const p = E.inCubic(seg(t, TL.leave0, TL.leave1));
    tx = lerp(tx, tx + 520, p); ty = lerp(ty, ty - 260, p); tA *= 1 - seg(t, TL.leave0 + 0.1, TL.leave1);
  }
  if (t >= TL.back) {
    // returns, fills three fields, taps the button
    const pts = [[1180, 1100], [620, keptSlot(0) + FH / 2], [640, keptSlot(4) + FH / 2], [660, keptSlot(10) + FH / 2], [770, BTN_FINAL + BTN_H / 2]];
    const times = [TL.back, TL.type0 - 0.05, TL.type0 + 0.34, TL.type0 + 0.68, TL.tap2 - 0.03];
    let k = 0; while (k < times.length - 2 && t > times[k + 1]) k++;
    const p = E.inOutCubic(seg(t, times[k], times[k + 1]));
    tx = lerp(pts[k][0], pts[k + 1][0], p); ty = lerp(pts[k][1], pts[k + 1][1], p);
    tA = seg(t, TL.back, TL.back + 0.2) * (1 - seg(t, TL.tap2 + 0.25, TL.tap2 + 0.45));
    if (t >= TL.tap2 - 0.05) rip = seg(t, TL.tap2, TL.tap2 + 0.45);
    for (const tt of [TL.type0 - 0.02, TL.type0 + 0.36, TL.type0 + 0.70]) { const kk = 1 - Math.abs(t - tt) / 0.09; if (kk > 0) tS = Math.min(tS, 1 - 0.18 * kk); }
    if (Math.abs(t - TL.tap2) < 0.1) tS = Math.min(tS, 1 - 0.2 * (1 - Math.abs(t - TL.tap2) / 0.1));
  }
  if (t < TL.leave1 || t >= TL.back) thumb(ctx, tx, ty, { scale: tS, alpha: tA, ripple: rip });

  // the button grows into the end card
  if (t >= TL.expand0) {
    const p = E.inOutCubic(seg(t, TL.expand0, TL.expand1));
    const x0 = lerp(M, 0, p), y0 = lerp(BTN_FINAL, 0, p), x1 = lerp(W - M, W, p), y1 = lerp(BTN_FINAL + BTN_H, H, p);
    rr(ctx, x0, y0, x1 - x0, y1 - y0, 22 * (1 - p)); ctx.fillStyle = C.ink; ctx.fill();
  }
}

function subframes(t) {
  if (t > INS[0] && t < INS[12] + 0.4) return 8;
  if (t > TL.leave0 && t < TL.leave1) return 6;
  if (t > TL.fall0 && t < TL.fall1 + 0.5) return 12;
  if (t > TL.back && t < TL.tap2 + 0.2) return 4;
  if (t > TL.expand0 && t < TL.expand1) return 10;
  return 1;
}

const CUES = {
  tap: [TL.tap, TL.tap2],
  fields: INS.slice(0, 12),
  fax: [TL.fax],
  lunges: LUNGES,
  leave: [TL.leave0],
  signature: [TL.fmIn, TL.expand1 + LOCKUP_LAND],
  strikes: ORDER.map((_, k) => TL.strike0 + k * TL.strikeGap),
  rewrite: [TL.rewrite0 + 0.14, TL.rewrite0 + 0.5],
  fall: [TL.fall0],
  roll: [TL.fall0 + 0.05, TL.fall0 + 0.6],
  springUp: [TL.springUp],
  type: [[TL.type0, TL.type0 + 0.22], [TL.type0 + 0.38, TL.type0 + 0.64], [TL.type0 + 0.72, TL.type0 + 1.27]],
  sent: [TL.sent],
  expand: [TL.expand0, TL.expand1],
  duration: TL.duration,
};

module.exports = { duration: TL.duration, draw, subframes, CUES, TL, INS };
