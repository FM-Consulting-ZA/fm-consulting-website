#!/usr/bin/env python3
"""FM brand films: sound design, synthesised from code.

No samples, no stock libraries, no music licences: every sound below is
generated here, so the films carry no third-party rights.

usage: python3 synth.py film1|film2 cues.json out.wav
"""
import sys, json
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 48000
rng = np.random.default_rng(7)


# ---------------------------------------------------------------- primitives
def t_(dur):
    return np.arange(int(dur * SR)) / SR


def env_ad(n, a, d, curve=6.0):
    """attack (s) then exponential decay over d (s)"""
    t = np.arange(n) / SR
    e = np.where(t < a, t / max(a, 1e-6), np.exp(-curve * (t - a) / max(d, 1e-6)))
    return e


def sine(f, dur, phase=0.0):
    t = t_(dur)
    if callable(f):
        ph = 2 * np.pi * np.cumsum(f(t)) / SR
        return np.sin(ph + phase)
    return np.sin(2 * np.pi * f * t + phase)


def noise(dur):
    return rng.standard_normal(int(dur * SR))


def bp(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, hi], btype='band', fs=SR, output='sos')
    return signal.sosfilt(sos, x)


def lp(x, f, order=2):
    sos = signal.butter(order, f, btype='low', fs=SR, output='sos')
    return signal.sosfilt(sos, x)


def hp(x, f, order=2):
    sos = signal.butter(order, f, btype='high', fs=SR, output='sos')
    return signal.sosfilt(sos, x)


class Mix:
    def __init__(self, dur):
        self.L = np.zeros(int(dur * SR) + SR)
        self.R = np.zeros_like(self.L)

    def add(self, x, at, gain=1.0, pan=0.0):
        i = int(at * SR)
        if i < 0:
            x = x[-i:]; i = 0
        n = min(len(x), len(self.L) - i)
        if n <= 0:
            return
        gl = gain * np.cos((pan + 1) * np.pi / 4) * np.sqrt(2)
        gr = gain * np.sin((pan + 1) * np.pi / 4) * np.sqrt(2)
        self.L[i:i + n] += x[:n] * gl
        self.R[i:i + n] += x[:n] * gr


# ---------------------------------------------------------------- sound kit
def tock(pitch=1.0):
    """FM signature: a dry, woody knock (both films use this, nowhere else)."""
    d = 0.5
    t = t_(d)
    body = (np.sin(2 * np.pi * 392 * pitch * t) * np.exp(-t * 38)
            + 0.55 * np.sin(2 * np.pi * 1046 * pitch * t) * np.exp(-t * 70)
            + 0.25 * np.sin(2 * np.pi * 196 * pitch * t) * np.exp(-t * 18))
    click = bp(noise(d), 1800, 6000) * np.exp(-t * 400) * 0.6
    return (body + click) * 0.9


def ui_send(soft=False):
    d = 0.22
    f = lambda t: 540 + 420 * np.clip(t / 0.07, 0, 1)
    x = sine(f, d) * env_ad(int(d * SR), 0.006, 0.12, 5)
    x += 0.2 * sine(lambda t: 2 * (540 + 420 * np.clip(t / 0.07, 0, 1)), d) * env_ad(int(d * SR), 0.004, 0.06, 5)
    return x * (0.45 if soft else 0.7)


def ding():
    """cheerful two-note message arrival"""
    out = np.zeros(int(0.9 * SR))
    for k, (f, at) in enumerate([(880, 0.0), (1318.5, 0.085)]):
        d = 0.8
        t = t_(d)
        x = (np.sin(2 * np.pi * f * t) + 0.18 * np.sin(2 * np.pi * f * 2.76 * t) * np.exp(-t * 12)) * np.exp(-t * 7)
        x *= np.clip(t / 0.004, 0, 1)
        i = int(at * SR)
        out[i:i + len(x)] += x[:len(out) - i] * 0.55
    return out


def tick(bright=1.0, dur=0.03):
    t = t_(dur)
    x = bp(noise(dur), 2500 * bright, 9000) * np.exp(-t * 320)
    x += 0.4 * np.sin(2 * np.pi * 3200 * bright * t) * np.exp(-t * 260)
    return x


def clock_tick(hi=True):
    d = 0.05
    t = t_(d)
    f = 2100 if hi else 1700
    x = np.sin(2 * np.pi * f * t) * np.exp(-t * 160) + 0.5 * bp(noise(d), 3000, 8000) * np.exp(-t * 500)
    return x * 0.5


def key_tick():
    d = 0.035
    t = t_(d)
    return (bp(noise(d), 1500, 5000) * np.exp(-t * 350) + 0.3 * np.sin(2 * np.pi * 900 * t) * np.exp(-t * 300)) * 0.5


def scratch(dur=0.12, pitch=1.0):
    """felt pen struck across paper"""
    t = t_(dur)
    x = bp(noise(dur), 1800 * pitch, 7000)
    grain = 0.6 + 0.4 * np.sign(np.sin(2 * np.pi * 55 * t + rng.random() * 6))
    e = np.clip(t / 0.01, 0, 1) * np.exp(-t * 9) * (1 - np.clip((t - dur + 0.02) / 0.02, 0, 1))
    return x * grain * e * 0.9


def whoosh(dur, lo=300, hi=3000, rise=True, gain=0.5):
    n = int(dur * SR)
    x = noise(dur)
    # time-varying band via short blocks
    out = np.zeros(n)
    B = 1024
    zi = None
    for s in range(0, n, B):
        p = s / n
        c = lo * (hi / lo) ** (p if rise else 1 - p)
        sos = signal.butter(2, [max(40, c * 0.6), min(SR / 2 - 100, c * 1.6)], btype='band', fs=SR, output='sos')
        blk = x[s:s + B]
        y = signal.sosfilt(sos, blk)
        out[s:s + len(blk)] = y
    e = np.sin(np.pi * np.clip(np.arange(n) / n, 0, 1)) ** 1.5
    return out * e * gain


def thud(f=180, dur=0.28, gain=1.0, card=0.5):
    """soft block landing: pitched body plus a card slap"""
    t = t_(dur)
    body = np.sin(2 * np.pi * f * t * (1 + 0.25 * np.exp(-t * 60))) * np.exp(-t * 22)
    slap = lp(bp(noise(dur), 400, 4000), 5000) * np.exp(-t * 90) * card
    return (body + slap) * gain


def pluck_up(f0=330, f1=660, dur=0.35):
    f = lambda t: f0 + (f1 - f0) * (1 - np.exp(-t * 30))
    x = sine(f, dur) * env_ad(int(dur * SR), 0.003, 0.25, 5)
    return x * 0.45


def chime():
    out = np.zeros(int(1.2 * SR))
    for f, at, g in [(1174.7, 0.0, 0.5), (1568, 0.07, 0.42), (2349.3, 0.14, 0.18)]:
        d = 1.0
        t = t_(d)
        x = (np.sin(2 * np.pi * f * t) + 0.12 * np.sin(2 * np.pi * f * 3.01 * t) * np.exp(-t * 10)) * np.exp(-t * 5.5)
        x *= np.clip(t / 0.003, 0, 1)
        i = int(at * SR)
        out[i:i + len(x)] += x[:len(out) - i] * g
    return out


def swell(dur=0.8):
    t = t_(dur + 1.6)
    e = np.clip(t / dur, 0, 1) ** 2 * np.exp(-np.clip(t - dur, 0, None) * 2.2)
    x = (np.sin(2 * np.pi * 55 * t) + 0.5 * np.sin(2 * np.pi * 82.4 * t)) * e
    x += lp(noise(dur + 1.6), 600) * e * 0.25
    return x * 0.55


def pad(freqs, dur, fade_in=1.0, fade_out=1.0, gain=0.1, detune=0.0):
    t = t_(dur)
    x = np.zeros_like(t)
    for k, f in enumerate(freqs):
        x += np.sin(2 * np.pi * f * t + k) + 0.6 * np.sin(2 * np.pi * f * (1 + detune) * t + 2 * k)
    e = np.clip(t / fade_in, 0, 1) * np.clip((dur - t) / fade_out, 0, 1)
    return lp(x, 900) * e * gain / len(freqs)


def room(dur, gain=0.012):
    x = lp(hp(noise(dur), 60), 1800)
    return x * gain


def reverb(x, secs=0.9, mix=0.14):
    n = int(secs * SR)
    t = np.arange(n) / SR
    ir = rng.standard_normal(n) * np.exp(-t * 6.5)
    ir = lp(ir, 5000)
    ir /= np.sqrt(np.sum(ir ** 2))
    wet = signal.fftconvolve(x, ir)[:len(x)]
    return x * (1 - mix) + wet * mix * 2.2


# ---------------------------------------------------------------- films
def film1(c):
    D = c['duration']
    m = Mix(D)
    m.add(room(D + 1), 0)
    m.add(ui_send(), c['send'][0], 0.8, 0.25)
    m.add(tick(1.2), c['read'][0], 0.25, 0.3)
    for tt in c['sendSoft']:
        m.add(ui_send(soft=True), tt, 0.7, 0.25)
    for tt in c['pill']:
        m.add(tick(0.8, 0.02), tt, 0.15)
    # time passing: one clock tick per simulated 20 minutes, air follows speed
    clock = np.array(c['clock'])
    vel = np.array(c['scrollVel'])
    last = 0
    last_t = -1
    hi = True
    s0, s1 = c['scroll']
    for k in range(len(clock)):
        tt = k * 0.01
        if tt < s0 or tt > s1 + 0.02:
            continue
        step = int(clock[k] // 20)
        if step > last and tt - last_t >= 0.075:
            last_t = tt
            speed = vel[k] / 1500.0
            m.add(clock_tick(hi), tt, 0.10 + 0.12 * min(1, speed), -0.35 if hi else -0.15)
            hi = not hi
            last = step
    # air proportional to scroll speed
    air = lp(hp(noise(D + 1), 200), 1400)
    envv = np.interp(np.arange(len(air)) / SR, np.arange(len(vel)) * 0.01, np.clip(vel / 1500, 0, 1))
    m.add(air * envv * 0.035, 0)
    # a low held tone while the customer waits: it cuts dead on the cheerful reply
    wait_pad = pad([73.42, 110.0], c['receive'][0] - s0 + 0.05, fade_in=2.4, fade_out=0.02, gain=0.12, detune=0.004)
    m.add(wait_pad, s0)
    m.add(ding(), c['receive'][0], 0.75, -0.2)
    # FM steps back
    z0, z1 = c['zoomOut']
    m.add(whoosh(z1 - z0 + 0.2, 1800, 350, True, 0.22), z0)
    m.add(tock(), c['signature'][0], 0.85)
    m.add(scratch(0.16), c['strike'][0], 0.38, -0.3)
    a, b = c['type']
    for k in range(6):
        m.add(key_tick(), a + (b - a) * k / 6, 0.5, -0.3)
    # the gap collapses: zip up, then a firm latch
    c0, c1 = c['collapse']
    m.add(whoosh(c1 - c0, 250, 3500, True, 0.55), c0 - 0.05)
    m.add(thud(150, 0.35, 0.9, 0.8), c1 - 0.02, 0.9)
    m.add(tock(0.75), c1 - 0.02, 0.35)
    i0, i1 = c['zoomIn']
    m.add(whoosh(i1 - i0, 2500, 500, True, 0.16), i0 + 0.1)
    # resolved pad under the fixed conversation
    m.add(pad([146.83, 220.0, 293.66], c['expand'][1] - c1 + 1.0, fade_in=0.9, fade_out=0.9, gain=0.11), c1)
    m.add(ui_send(), c['send'][1], 0.8, 0.25)
    e0, e1 = c['expand']
    m.add(swell(e1 - e0), e0, 0.5)
    m.add(tock(), c['signature'][1], 0.9)
    m.add(pad([146.83, 185.0, 220.0, 293.66], D - e1, fade_in=0.6, fade_out=1.6, gain=0.09), e1)
    return m


def film2(c):
    D = c['duration']
    m = Mix(D)
    m.add(room(D + 1), 0)
    m.add(tick(0.9, 0.04), c['tap'][0], 0.6)
    # fields: pitch climbs a semitone per field, rhythm tightens by itself
    for k, tt in enumerate(c['fields']):
        f = 165 * 2 ** (k / 12)
        m.add(thud(f, 0.25, 0.75, 0.55), tt, 0.75, (k % 2 - 0.5) * 0.3)
    # tension bed under the stacking
    f0 = c['fields'][0]
    m.add(pad([82.4, 123.5], c['fax'][0] - f0 + 0.3, fade_in=2.5, fade_out=0.05, gain=0.12, detune=0.006), f0)
    for tt in c['lunges']:
        m.add(whoosh(0.14, 1200, 3000, True, 0.12), tt - 0.06)
    # the last straw: heavier, lower, with a rattle
    fx = c['fax'][0]
    m.add(thud(98, 0.5, 1.2, 1.0), fx, 1.0)
    for k in range(4):
        m.add(tick(0.5, 0.03), fx + 0.05 + k * 0.045, 0.12 * (1 - k / 4))
    m.add(whoosh(0.35, 2500, 700, True, 0.14), c['leave'][0], 1.0, 0.5)
    # FM
    m.add(tock(), c['signature'][0], 0.9)
    for k, tt in enumerate(c['strikes']):
        m.add(scratch(0.075, 1 + 0.06 * (k % 3)), tt, 0.34, -0.4 + 0.08 * k)
    a, b = c['rewrite']
    for k in range(8):
        m.add(key_tick(), a + (b - a) * k / 8, 0.45)
    fl = c['fall'][0]
    m.add(whoosh(0.7, 2000, 250, True, 0.32), fl)
    for k in range(10):
        m.add(thud(120 + 15 * (k % 4), 0.18, 0.18, 0.7), fl + 0.28 + 0.035 * k + 0.02 * rng.random(), 0.5, rng.uniform(-0.6, 0.6))
    r0, r1 = c['roll']
    for k in range(10):
        m.add(tick(1.4, 0.02), r0 + (r1 - r0) * k / 10, 0.12)
    m.add(pluck_up(330, 660), c['springUp'][0] + 0.05, 0.9)
    m.add(tick(1.0, 0.03), c['springUp'][0] + 0.2, 0.3)
    # resolved bed
    m.add(pad([164.8, 246.9, 329.6], c['expand'][1] - c['springUp'][0] + 0.6, fade_in=0.8, fade_out=0.8, gain=0.1), c['springUp'][0])
    for (a, b), nch in zip(c['type'], [4, 12, 26]):
        nt = max(3, min(10, nch // 2 + 2))
        for k in range(nt):
            m.add(key_tick(), a + (b - a) * k / nt, 0.4)
    m.add(tick(0.9, 0.04), c['tap'][1], 0.6)
    m.add(chime(), c['sent'][0], 0.7)
    e0, e1 = c['expand']
    m.add(swell(e1 - e0), e0, 0.5)
    m.add(tock(), c['signature'][1], 0.9)
    m.add(pad([164.8, 207.7, 246.9, 329.6], D - e1, fade_in=0.6, fade_out=1.6, gain=0.09), e1)
    return m


if __name__ == '__main__':
    which, cues, out = sys.argv[1], sys.argv[2], sys.argv[3]
    c = json.load(open(cues))
    m = film1(c) if which == 'film1' else film2(c)
    n = int(c['duration'] * SR)
    L, R = reverb(m.L[:n]), reverb(m.R[:n])
    # gentle fade at the very end
    f = np.ones(n); f[-int(0.25 * SR):] = np.linspace(1, 0, int(0.25 * SR))
    st = np.stack([L * f, R * f], 1)
    st /= max(1e-9, np.max(np.abs(st))) / 0.7
    wavfile.write(out, SR, (st * 32767).astype(np.int16))
    print('wrote', out, st.shape[0] / SR, 's')
