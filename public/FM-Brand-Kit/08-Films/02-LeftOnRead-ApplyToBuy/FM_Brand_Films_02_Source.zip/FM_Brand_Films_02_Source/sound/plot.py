import sys, json, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.io import wavfile
wav, cues, out = sys.argv[1:4]
sr, x = wavfile.read(wav); x = x.astype(float).mean(1) / 32768
c = json.load(open(cues))
fig, ax = plt.subplots(2, 1, figsize=(18, 7), sharex=True)
t = np.arange(len(x)) / sr
# short-term loudness proxy (RMS dB, 50 ms)
w = int(0.05 * sr); r = np.sqrt(np.convolve(x**2, np.ones(w)/w, 'same')) + 1e-6
ax[0].plot(t, 20*np.log10(r), lw=0.6); ax[0].set_ylim(-70, 0); ax[0].set_ylabel('RMS dB')
ax[1].specgram(x, NFFT=2048, Fs=sr, noverlap=1536, cmap='magma', vmin=-120); ax[1].set_ylim(0, 8000)
cols = plt.cm.tab20.colors
k = 0
for name, v in c.items():
    if name in ('duration', 'scrollVel', 'clock'): continue
    vals = []
    for e in v:
        vals += e if isinstance(e, list) else [e]
    for tv in vals:
        ax[0].axvline(tv, color=cols[k % 20], lw=0.8); 
    ax[0].text(vals[0], -5 - (k % 6) * 8, name, fontsize=8, color=cols[k % 20])
    k += 1
plt.tight_layout(); plt.savefig(out, dpi=80)
