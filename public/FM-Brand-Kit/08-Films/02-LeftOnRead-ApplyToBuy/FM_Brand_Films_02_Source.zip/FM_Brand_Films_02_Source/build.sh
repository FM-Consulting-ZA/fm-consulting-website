#!/bin/bash
# Rebuild both FM brand films from source.
# Needs: node 18+, ffmpeg, python3 with numpy + scipy.  First run: npm install
set -e
cd "$(dirname "$0")"
mkdir -p final sound
for f in film1_left_on_read film2_apply_to_buy; do
  node render.js $f.js cues > sound/cues_${f%%_*}.json
done
python3 sound/synth.py film1 sound/cues_film1.json sound/film1_raw.wav
python3 sound/synth.py film2 sound/cues_film2.json sound/film2_raw.wav
CRF=14 node render.js film1_left_on_read.js video final/film1_video.mp4
CRF=14 node render.js film2_apply_to_buy.js video final/film2_video.mp4
./mux.sh final/film1_video.mp4 sound/film1_raw.wav final/FM_LeftOnRead_1080x1920.mp4
./mux.sh final/film2_video.mp4 sound/film2_raw.wav final/FM_ApplyToBuy_1080x1920.mp4
node extras.js      # covers, style frames, storyboards
echo "done: final/"
