// usage: node render.js <film.js> stills <t1,t2,...> [scale]   |  node render.js <film.js> video <out.mp4> [from] [to]
'use strict';
const path = require('path');
const X = require('./lib/engine');
const [,, filmFile, mode, arg, a4, a5] = process.argv;
const film = require(path.resolve(filmFile));
(async () => {
  if (mode === 'stills') {
    const ts = arg.split(',').map(Number);
    const scale = a4 ? Number(a4) : 1;
    const base = path.basename(filmFile, '.js');
    for (const t of ts) {
      const f = `stills/${base}_${t.toFixed(2)}.png`;
      X.renderStill(film, t, f, scale);
      console.log(f);
    }
  } else if (mode === 'video') {
    await X.renderVideo(film, arg, { from: a4 ? Number(a4) : 0, to: a5 ? Number(a5) : film.duration, crf: process.env.CRF ? Number(process.env.CRF) : 16, preset: process.env.PRESET || 'slow', maxSub: process.env.MAXSUB ? Number(process.env.MAXSUB) : 12 });
    console.log('wrote', arg);
  } else if (mode === 'cues') {
    console.log(JSON.stringify(film.CUES, null, 1));
  }
})();
